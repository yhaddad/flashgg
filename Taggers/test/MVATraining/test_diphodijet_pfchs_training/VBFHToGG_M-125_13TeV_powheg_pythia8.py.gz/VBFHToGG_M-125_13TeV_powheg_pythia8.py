import FWCore.ParameterSet.Config as cms

process = cms.Process("VBFDiPhoDiJetMVATraining")

process.source = cms.Source("PoolSource",
    fileNames = cms.untracked.vstring('root://xrootd-cms.infn.it//store/group/phys_higgs/cmshgg/yhaddad/flashgg/flashggMicroAODSpring15/Spring15MicroAODforJets/VBFHToGG_M-125_13TeV_powheg_pythia8/flashggMicroAODSpring15-Spring15MicroAODforJets-v0-RunIISpring15DR74-Asympt50ns_MCRUN2_74_V9A-v1/150923_131713/0000/myMicroAODOutputFile_1.root')
)
process.flashggDiPhotonMVA = cms.EDProducer("FlashggDiPhotonMVAProducer",
    BeamSpotTag = cms.InputTag("offlineBeamSpot"),
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    Version = cms.string('old'),
    VertexProbParamsConv = cms.vdouble(-0.049, -0.241, -0.505, -0.27),
    VertexProbParamsNoConv = cms.vdouble(-0.344, -0.091, -0.234, -0.186),
    diphotonMVAweightfile = cms.FileInPath('flashgg/Taggers/data/HggBambu_SMDipho_Oct29_rwgtptallsigevenbkg7TeV_BDTG.weights.xml')
)


process.flashggDiPhotonMVANew = cms.EDProducer("FlashggDiPhotonMVAProducer",
    BeamSpotTag = cms.InputTag("offlineBeamSpot"),
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    Version = cms.string('new'),
    VertexProbParamsConv = cms.vdouble(-0.049, -0.241, -0.505, -0.27),
    VertexProbParamsNoConv = cms.vdouble(-0.344, -0.091, -0.234, -0.186),
    diphotonMVAweightfile = cms.FileInPath('flashgg/Taggers/data/Flashgg_DiPhoton_BDTG.weights.xml')
)


process.flashggDiPhotonMVAPUPPI = cms.EDProducer("FlashggDiPhotonMVAProducer",
    BeamSpotTag = cms.InputTag("offlineBeamSpot"),
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    Version = cms.string('new'),
    VertexProbParamsConv = cms.vdouble(-0.049, -0.241, -0.505, -0.27),
    VertexProbParamsNoConv = cms.vdouble(-0.344, -0.091, -0.234, -0.186),
    diphotonMVAweightfile = cms.FileInPath('flashgg/Taggers/data/Flashgg_DiPhoton_BDTG.weights.xml')
)


process.flashggTTHHadronicTag = cms.EDProducer("FlashggTTHHadronicTagProducer",
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    SystLabel = cms.string(''),
    bDiscriminatorLoose = cms.untracked.double(0.275),
    bDiscriminatorMedium = cms.untracked.double(0.545),
    bTag = cms.untracked.string('pfCombinedInclusiveSecondaryVertexV2BJetTags'),
    bjetsNumberThreshold = cms.untracked.int32(0),
    inputTagJets = cms.VInputTag(cms.InputTag("flashggUnpackedJets","0"), cms.InputTag("flashggUnpackedJets","1"), cms.InputTag("flashggUnpackedJets","2"), cms.InputTag("flashggUnpackedJets","3"), cms.InputTag("flashggUnpackedJets","4"), 
        cms.InputTag("flashggUnpackedJets","5"), cms.InputTag("flashggUnpackedJets","6"), cms.InputTag("flashggUnpackedJets","7")),
    jetsNumberThreshold = cms.untracked.int32(4)
)


process.flashggTTHLeptonicTag = cms.EDProducer("FlashggTTHLeptonicTagProducer",
    DeltaRTrkElec = cms.untracked.double(1.0),
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    ElectronPtThreshold = cms.untracked.double(20.0),
    ElectronTag = cms.InputTag("flashggSelectedElectrons"),
    EtaCuts = cms.untracked.vdouble(1.442, 1.566, 2.5),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    HighEtaPhoThreshold = cms.untracked.double(2.5),
    LongitudinalImpactParam = cms.untracked.double(0.02),
    LowPtEtaPhoThreshold = cms.untracked.double(1.4447),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.untracked.double(-0.6),
    MidPtEtaPhoThreshold = cms.untracked.double(1.566),
    MuonTag = cms.InputTag("flashggSelectedMuons"),
    PhoMVAThreshold = cms.untracked.double(-0.2),
    PuIDCutoffThreshold = cms.untracked.double(0.8),
    SystLabel = cms.string(''),
    TransverseImpactParam = cms.untracked.double(0.2),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    Zmass_ = cms.untracked.double(91.9),
    bDiscriminator = cms.untracked.vdouble(0.275, 0.545),
    bTag = cms.untracked.string('pfCombinedInclusiveSecondaryVertexV2BJetTags'),
    bjetsNumberThreshold = cms.untracked.double(1.0),
    deltaMassElectronZThreshold_ = cms.untracked.double(10.0),
    deltaRJetLeadPhoThreshold = cms.untracked.double(0.5),
    deltaRJetLepThreshold = cms.untracked.double(0.5),
    deltaRJetSubLeadPhoThreshold = cms.untracked.double(0.5),
    deltaRLepPhoThreshold = cms.untracked.double(0.5),
    deltaRMuonJetcountThreshold = cms.untracked.double(2.0),
    deltaRPhoElectronThreshold = cms.untracked.double(1.0),
    electronIsoThreshold = cms.untracked.double(0.15),
    electronNumOfHitsThreshold = cms.untracked.double(1),
    inputTagJets = cms.VInputTag(cms.InputTag("flashggUnpackedJets","0"), cms.InputTag("flashggUnpackedJets","1"), cms.InputTag("flashggUnpackedJets","2"), cms.InputTag("flashggUnpackedJets","3"), cms.InputTag("flashggUnpackedJets","4"), 
        cms.InputTag("flashggUnpackedJets","5"), cms.InputTag("flashggUnpackedJets","6"), cms.InputTag("flashggUnpackedJets","7")),
    jetEtaThreshold = cms.untracked.double(2.4),
    jetPtThreshold = cms.untracked.double(30.0),
    jetsNumberThreshold = cms.untracked.double(2.0),
    leadPhoOverMassThreshold = cms.untracked.double(0.5),
    leptonEtaThreshold = cms.untracked.double(2.4),
    leptonPtThreshold = cms.untracked.double(20),
    muPFIsoSumRelThreshold = cms.untracked.double(0.2),
    nonTrigMVAThreshold = cms.untracked.double(0.9),
    subleadPhoOverMassThreshold = cms.untracked.double(0.25)
)


process.flashggTagSorter = cms.EDProducer("FlashggTagSorter",
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    TagPriorityRanges = cms.VPSet(cms.PSet(
        TagName = cms.InputTag("flashggVHTightTag")
    ), 
        cms.PSet(
            TagName = cms.InputTag("flashggVHLooseTag")
        ), 
        cms.PSet(
            TagName = cms.InputTag("flashggVHHadronicTag")
        ), 
        cms.PSet(
            TagName = cms.InputTag("flashggVHEtTag")
        ), 
        cms.PSet(
            TagName = cms.InputTag("flashggTTHLeptonicTag")
        ), 
        cms.PSet(
            TagName = cms.InputTag("flashggTTHHadronicTag")
        ), 
        cms.PSet(
            MaxCategory = cms.untracked.int32(0),
            MinCategory = cms.untracked.int32(0),
            TagName = cms.InputTag("flashggVBFTag")
        ), 
        cms.PSet(
            MaxCategory = cms.untracked.int32(1),
            MinCategory = cms.untracked.int32(0),
            TagName = cms.InputTag("flashggUntagged")
        ), 
        cms.PSet(
            MaxCategory = cms.untracked.int32(2),
            MinCategory = cms.untracked.int32(1),
            TagName = cms.InputTag("flashggVBFTag")
        ), 
        cms.PSet(
            MaxCategory = cms.untracked.int32(4),
            MinCategory = cms.untracked.int32(2),
            TagName = cms.InputTag("flashggUntagged")
        )),
    massCutLower = cms.untracked.double(100),
    massCutUpper = cms.untracked.double(180.0)
)


process.flashggUnpackedJets = cms.EDProducer("FlashggVectorVectorJetUnpacker",
    JetsTag = cms.InputTag("flashggFinalJets"),
    NCollections = cms.uint32(8)
)


process.flashggUnpackedPuppiJets = cms.EDProducer("FlashggVectorVectorJetUnpacker",
    JetsTag = cms.InputTag("flashggFinalPuppiJets"),
    NCollections = cms.uint32(8)
)


process.flashggUntagged = cms.EDProducer("FlashggUntaggedTagProducer",
    Boundaries = cms.untracked.vdouble(0.07, 0.31, 0.62, 0.86, 0.98),
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    SystLabel = cms.string('')
)


process.flashggVBFDiPhoDiJetMVA = cms.EDProducer("FlashggVBFDiPhoDiJetMVAProducer",
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    UseLegacyMVA = cms.untracked.bool(True),
    VBFMVAResultTag = cms.InputTag("flashggVBFMVA"),
    vbfDiPhoDiJetMVAweightfile = cms.FileInPath('flashgg/Taggers/data/TMVA_vbf_dijet_dipho_evenbkg_scaledwt50_maxdPhi_Gradient.weights.xml')
)


process.flashggVBFDiPhoDiJetMVANew = cms.EDProducer("FlashggVBFDiPhoDiJetMVAProducer",
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    UseLegacyMVA = cms.untracked.bool(False),
    VBFMVAResultTag = cms.InputTag("flashggVBFMVANew"),
    vbfDiPhoDiJetMVAweightfile = cms.FileInPath('flashgg/Taggers/data/Flashgg_DiPhoDiJet_BDT.weights.xml')
)


process.flashggVBFDiPhoDiJetMVAPUPPI = cms.EDProducer("FlashggVBFDiPhoDiJetMVAProducer",
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    UseLegacyMVA = cms.untracked.bool(False),
    VBFMVAResultTag = cms.InputTag("flashggVBFMVAPUPPI"),
    vbfDiPhoDiJetMVAweightfile = cms.FileInPath('flashgg/Taggers/data/Flashgg_DiPhoDiJet_BDT.weights.xml')
)


process.flashggVBFMVA = cms.EDProducer("FlashggVBFMVAProducer",
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    MinDijetMinv = cms.double(0.0),
    UseLegacyMVA = cms.untracked.bool(True),
    inputTagJets = cms.VInputTag(cms.InputTag("flashggUnpackedJets","0"), cms.InputTag("flashggUnpackedJets","1"), cms.InputTag("flashggUnpackedJets","2"), cms.InputTag("flashggUnpackedJets","3"), cms.InputTag("flashggUnpackedJets","4"), 
        cms.InputTag("flashggUnpackedJets","5"), cms.InputTag("flashggUnpackedJets","6"), cms.InputTag("flashggUnpackedJets","7")),
    vbfMVAweightfile = cms.FileInPath('flashgg/Taggers/data/TMVA_dijet_sherpa_scalewt50_2evenb_powheg200_maxdPhi_oct9_Gradient.weights.xml')
)


process.flashggVBFMVANew = cms.EDProducer("FlashggVBFMVAProducer",
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    MinDijetMinv = cms.double(0.0),
    UseLegacyMVA = cms.untracked.bool(False),
    inputTagJets = cms.VInputTag(cms.InputTag("flashggUnpackedJets","0"), cms.InputTag("flashggUnpackedJets","1"), cms.InputTag("flashggUnpackedJets","2"), cms.InputTag("flashggUnpackedJets","3"), cms.InputTag("flashggUnpackedJets","4"), 
        cms.InputTag("flashggUnpackedJets","5"), cms.InputTag("flashggUnpackedJets","6"), cms.InputTag("flashggUnpackedJets","7")),
    vbfMVAweightfile = cms.FileInPath('flashgg/Taggers/data/Flashgg_VBF_BDT.weights.xml')
)


process.flashggVBFMVAPUPPI = cms.EDProducer("FlashggVBFMVAProducer",
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    MinDijetMinv = cms.double(0.0),
    UseLegacyMVA = cms.untracked.bool(False),
    inputTagJets = cms.VInputTag(cms.InputTag("flashggUnpackedPuppiJets","0"), cms.InputTag("flashggUnpackedPuppiJets","1"), cms.InputTag("flashggUnpackedPuppiJets","2"), cms.InputTag("flashggUnpackedPuppiJets","3"), cms.InputTag("flashggUnpackedPuppiJets","4"), 
        cms.InputTag("flashggUnpackedPuppiJets","5"), cms.InputTag("flashggUnpackedPuppiJets","6"), cms.InputTag("flashggUnpackedPuppiJets","7")),
    vbfMVAweightfile = cms.FileInPath('flashgg/Taggers/data/Flashgg_VBF_BDT.weights.xml')
)


process.flashggVBFTag = cms.EDProducer("FlashggVBFTagProducer",
    Boundaries = cms.untracked.vdouble(0.21, 0.6, 0.81),
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    GenJetTag = cms.InputTag("slimmedGenJets"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    SystLabel = cms.string(''),
    VBFDiPhoDiJetMVAResultTag = cms.InputTag("flashggVBFDiPhoDiJetMVA"),
    VBFMVAResultTag = cms.InputTag("flashggVBFMVA")
)


process.flashggVHEtTag = cms.EDProducer("FlashggVHEtTagProducer",
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    METTag = cms.InputTag("slimmedMETs"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    SystLabel = cms.string('')
)


process.flashggVHHadronicTag = cms.EDProducer("FlashggVHHadronicTagProducer",
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.untracked.double(-0.6),
    PhoMVAThreshold = cms.untracked.double(-0.2),
    SystLabel = cms.string(''),
    cosThetaStarThreshold = cms.untracked.double(0.5),
    dRJetToPhoLThreshold = cms.untracked.double(0.5),
    dRJetToPhoSThreshold = cms.untracked.double(0.5),
    dijetMassHighThreshold = cms.untracked.double(120.0),
    dijetMassLowThreshold = cms.untracked.double(60.0),
    inputTagJets = cms.VInputTag(cms.InputTag("flashggUnpackedJets","0"), cms.InputTag("flashggUnpackedJets","1"), cms.InputTag("flashggUnpackedJets","2"), cms.InputTag("flashggUnpackedJets","3"), cms.InputTag("flashggUnpackedJets","4"), 
        cms.InputTag("flashggUnpackedJets","5"), cms.InputTag("flashggUnpackedJets","6"), cms.InputTag("flashggUnpackedJets","7")),
    jetEtaThreshold = cms.untracked.double(2.4),
    jetPtThreshold = cms.untracked.double(40.0),
    jetsNumberThreshold = cms.untracked.double(2.0),
    leadPhoOverMassThreshold = cms.untracked.double(0.375),
    subleadPhoOverMassThreshold = cms.untracked.double(0.25)
)


process.flashggVHLooseTag = cms.EDProducer("FlashggVHLooseTagProducer",
    DeltaRTrkElec = cms.untracked.double(1.0),
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    ElectronPtThreshold = cms.untracked.double(20.0),
    ElectronTag = cms.InputTag("flashggSelectedElectrons"),
    EtaCuts = cms.untracked.vdouble(1.442, 1.566, 2.5),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    HighEtaPhoThreshold = cms.untracked.double(2.5),
    LongitudinalImpactParam = cms.untracked.double(0.02),
    LowPtEtaPhoThreshold = cms.untracked.double(1.4447),
    METTag = cms.InputTag("slimmedMETs"),
    METThreshold = cms.untracked.double(45.0),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.untracked.double(-0.6),
    MidPtEtaPhoThreshold = cms.untracked.double(1.566),
    MuonTag = cms.InputTag("flashggSelectedMuons"),
    PhoMVAThreshold = cms.untracked.double(-0.2),
    PuIDCutoffThreshold = cms.untracked.double(0.8),
    SystLabel = cms.string(''),
    TransverseImpactParam = cms.untracked.double(0.2),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    Zmass_ = cms.untracked.double(91.9),
    deltaMassElectronZThreshold_ = cms.untracked.double(10.0),
    deltaRLepPhoThreshold = cms.untracked.double(1),
    deltaRPhoElectronThreshold = cms.untracked.double(1.0),
    electronIsoThreshold = cms.untracked.double(0.15),
    electronNumOfHitsThreshold = cms.untracked.double(1),
    inputTagJets = cms.VInputTag(cms.InputTag("flashggUnpackedJets","0"), cms.InputTag("flashggUnpackedJets","1"), cms.InputTag("flashggUnpackedJets","2"), cms.InputTag("flashggUnpackedJets","3"), cms.InputTag("flashggUnpackedJets","4"), 
        cms.InputTag("flashggUnpackedJets","5"), cms.InputTag("flashggUnpackedJets","6"), cms.InputTag("flashggUnpackedJets","7")),
    jetEtaThreshold = cms.untracked.double(2.4),
    jetPtThreshold = cms.untracked.double(20.0),
    jetsNumberThreshold = cms.untracked.double(3.0),
    leadPhoOverMassThreshold = cms.untracked.double(0.375),
    leptonEtaThreshold = cms.untracked.double(2.4),
    leptonPtThreshold = cms.untracked.double(20),
    muPFIsoSumRelThreshold = cms.untracked.double(0.2),
    nonTrigMVAThreshold = cms.untracked.double(0.9),
    subleadPhoOverMassThreshold = cms.untracked.double(0.25)
)


process.flashggVHTightTag = cms.EDProducer("FlashggVHTightTagProducer",
    DeltaRTrkElec = cms.untracked.double(1.0),
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    ElectronPtThreshold = cms.untracked.double(20.0),
    ElectronTag = cms.InputTag("flashggSelectedElectrons"),
    EtaCuts = cms.untracked.vdouble(1.442, 1.566, 2.5),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    HighEtaPhoThreshold = cms.untracked.double(2.5),
    LongitudinalImpactParam = cms.untracked.double(0.02),
    LowPtEtaPhoThreshold = cms.untracked.double(1.4447),
    METTag = cms.InputTag("slimmedMETs"),
    METThreshold = cms.untracked.double(45.0),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.untracked.double(-0.6),
    MidPtEtaPhoThreshold = cms.untracked.double(1.566),
    MuonTag = cms.InputTag("flashggSelectedMuons"),
    PhoMVAThreshold = cms.untracked.double(-0.2),
    PuIDCutoffThreshold = cms.untracked.double(0.8),
    SystLabel = cms.string(''),
    TransverseImpactParam = cms.untracked.double(0.2),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    Zmass_ = cms.untracked.double(91.9),
    deltaMassElectronZThreshold_ = cms.untracked.double(10.0),
    deltaRJetMuonThreshold = cms.untracked.double(0.5),
    deltaRLepPhoThreshold = cms.untracked.double(1),
    deltaRLowPtMuonPhoThreshold = cms.untracked.double(0.5),
    deltaRPhoElectronThreshold = cms.untracked.double(1.0),
    deltaRPhoLeadJet = cms.untracked.double(0.5),
    deltaRPhoSubLeadJet = cms.untracked.double(0.5),
    electronIsoThreshold = cms.untracked.double(0.15),
    electronNumOfHitsThreshold = cms.untracked.double(1),
    inputTagJets = cms.VInputTag(cms.InputTag("flashggUnpackedJets","0"), cms.InputTag("flashggUnpackedJets","1"), cms.InputTag("flashggUnpackedJets","2"), cms.InputTag("flashggUnpackedJets","3"), cms.InputTag("flashggUnpackedJets","4"), 
        cms.InputTag("flashggUnpackedJets","5"), cms.InputTag("flashggUnpackedJets","6"), cms.InputTag("flashggUnpackedJets","7")),
    invMassLepHighThreshold = cms.untracked.double(110.0),
    invMassLepLowThreshold = cms.untracked.double(70.0),
    jetEtaThreshold = cms.untracked.double(2.4),
    jetPtThreshold = cms.untracked.double(20.0),
    jetsNumberThreshold = cms.untracked.double(3.0),
    leadPhoOverMassThreshold = cms.untracked.double(0.375),
    leptonEtaThreshold = cms.untracked.double(2.4),
    leptonLowPtThreshold = cms.untracked.double(10.0),
    leptonPtThreshold = cms.untracked.double(20),
    muPFIsoSumRelThreshold = cms.untracked.double(0.2),
    nonTrigMVAThreshold = cms.untracked.double(0.9),
    numberOfHighPtMuonsThreshold = cms.untracked.double(1.0),
    numberOfLowPtMuonsThreshold = cms.untracked.double(2.0),
    subleadPhoOverMassThreshold = cms.untracked.double(0.25)
)


process.VBFDiPhoDiJetMVADumperNew = cms.EDAnalyzer("CutBasedVBFDiPhoDiJetMVAResultDumper",
    categories = cms.VPSet(cms.PSet(
        histograms = cms.VPSet(cms.PSet(
            name = cms.untracked.string('VBFDiPhoDiJetMVAResult'),
            nxbins = cms.untracked.int32(400),
            x = cms.untracked.string('VBFDiPhoDiJetMVAResult'),
            xmax = cms.untracked.double(1.0),
            xmin = cms.untracked.double(-1.0)
        )),
        label = cms.string('All'),
        subcats = cms.int32(0),
        systLabel = cms.string(''),
        variables = cms.VPSet(cms.PSet(
            expr = cms.string('dijet_mva'),
            name = cms.untracked.string('dijet_mva')
        ), 
            cms.PSet(
                expr = cms.string('dipho_mva'),
                name = cms.untracked.string('dipho_mva')
            ), 
            cms.PSet(
                expr = cms.string('dipho_PToM'),
                name = cms.untracked.string('dipho_PToM')
            ), 
            cms.PSet(
                expr = cms.string('vbfDiPhoDiJetMvaResult'),
                name = cms.untracked.string('vbfDiPhoDiJetMvaResult')
            ))
    )),
    className = cms.untracked.string('CutBasedVBFDiPhoDiJetMVAResultDumper'),
    classifierCfg = cms.PSet(
        categories = cms.VPSet(cms.PSet(
            cut = cms.string('dipho_PToM>=0'),
            name = cms.untracked.string('')
        ))
    ),
    dumpGlobalVariables = cms.untracked.bool(True),
    dumpHistos = cms.untracked.bool(True),
    dumpTrees = cms.untracked.bool(True),
    dumpWorkspace = cms.untracked.bool(False),
    generatorInfo = cms.InputTag("generator"),
    globalVariables = cms.PSet(
        rho = cms.InputTag("fixedGridRhoAll"),
        vertexes = cms.InputTag("offlineSlimmedPrimaryVertices")
    ),
    lumiWeight = cms.double(0.01709088),
    maxCandPerEvent = cms.int32(1),
    nameTemplate = cms.untracked.string('$PROCESS_$SQRTS_$LABEL_$SUBCAT'),
    processId = cms.string('vbf_m125'),
    quietRooFit = cms.untracked.bool(True),
    src = cms.InputTag("flashggVBFDiPhoDiJetMVANew"),
    workspaceName = cms.untracked.string('cms_hgg_$SQRTS')
)


process.VBFMVADumperNew = cms.EDAnalyzer("CutBasedVBFMVAResultDumper",
    categories = cms.VPSet(cms.PSet(
        histograms = cms.VPSet(cms.PSet(
            name = cms.untracked.string('outputBDT'),
            nxbins = cms.untracked.int32(400),
            x = cms.untracked.string('vbfMvaResult_value'),
            xmax = cms.untracked.double(1.0),
            xmin = cms.untracked.double(-1.0)
        )),
        label = cms.string('All'),
        subcats = cms.int32(0),
        systLabel = cms.string(''),
        variables = cms.VPSet(cms.PSet(
            expr = cms.string('dijet_abs_dEta'),
            name = cms.untracked.string('dijet_abs_dEta')
        ), 
            cms.PSet(
                expr = cms.string('dijet_leadEta'),
                name = cms.untracked.string('dijet_leadEta')
            ), 
            cms.PSet(
                expr = cms.string('dijet_subleadEta'),
                name = cms.untracked.string('dijet_subleadEta')
            ), 
            cms.PSet(
                expr = cms.string('dijet_LeadJPt'),
                name = cms.untracked.string('dijet_LeadJPt')
            ), 
            cms.PSet(
                expr = cms.string('dijet_SubJPt'),
                name = cms.untracked.string('dijet_SubJPt')
            ), 
            cms.PSet(
                expr = cms.string('dijet_Zep'),
                name = cms.untracked.string('dijet_Zep')
            ), 
            cms.PSet(
                expr = cms.string('dijet_Mjj'),
                name = cms.untracked.string('dijet_Mjj')
            ), 
            cms.PSet(
                expr = cms.string('dipho_PToM'),
                name = cms.untracked.string('dipho_PToM')
            ), 
            cms.PSet(
                expr = cms.string('leadPho_PToM'),
                name = cms.untracked.string('leadPho_PToM')
            ), 
            cms.PSet(
                expr = cms.string('sublPho_PToM'),
                name = cms.untracked.string('sublPho_PToM')
            ), 
            cms.PSet(
                expr = cms.string('dijet_dPhi_trunc'),
                name = cms.untracked.string('dijet_dPhi_trunc')
            ), 
            cms.PSet(
                expr = cms.string('vbfMvaResult_value'),
                name = cms.untracked.string('vbfMvaResult_value')
            ))
    )),
    className = cms.untracked.string('CutBasedVBFMVAResultDumper'),
    classifierCfg = cms.PSet(
        categories = cms.VPSet(cms.PSet(
            cut = cms.string('dijet_LeadJPt >0'),
            name = cms.untracked.string('')
        ))
    ),
    dumpGlobalVariables = cms.untracked.bool(True),
    dumpHistos = cms.untracked.bool(True),
    dumpTrees = cms.untracked.bool(True),
    dumpWorkspace = cms.untracked.bool(False),
    generatorInfo = cms.InputTag("generator"),
    globalVariables = cms.PSet(
        rho = cms.InputTag("fixedGridRhoAll"),
        vertexes = cms.InputTag("offlineSlimmedPrimaryVertices")
    ),
    lumiWeight = cms.double(0.01709088),
    maxCandPerEvent = cms.int32(1),
    nameTemplate = cms.untracked.string('$PROCESS_$SQRTS_$LABEL_$SUBCAT'),
    processId = cms.string('vbf_m125'),
    quietRooFit = cms.untracked.bool(True),
    src = cms.InputTag("flashggVBFMVANew"),
    workspaceName = cms.untracked.string('cms_hgg_$SQRTS')
)


process.flashggTagTester = cms.EDAnalyzer("FlashggTagTestAnalyzer",
    TagSorter = cms.InputTag("flashggTagSorter")
)


process.out = cms.OutputModule("PoolOutputModule",
    fileName = cms.untracked.string('/home/hep/yhaddad/work/CMSSW_7_4_12/src/flashgg/Taggers/test/MVATraining/test_diphodijet_pfchs_training/output_VBFHToGG_M-125_13TeV_powheg_pythia8_numEvent5000.root'),
    outputCommands = cms.untracked.vstring('drop *', 
        'keep *_flashgg*_*_*', 
        'drop *_flashggVertexMap*_*_*', 
        'drop *_flashggDiPhotons_*_*', 
        'drop *_flashggPuppi*_*_*', 
        'drop patPackedCandidates_*_*_*', 
        'drop *_flashggPrunedGenParticles_*_*', 
        'keep recoGenParticles_flashggPrunedGenParticles_*_*', 
        'keep recoVertexs_offlineSlimmedPrimaryVertices_*_*', 
        'keep *_reducedEgamma_reducedSuperClusters_*', 
        'keep *_reducedEgamma_*PhotonCores_*', 
        'keep *_slimmedMETs_*_*', 
        'keep *_fixedGridRhoAll_*_*', 
        'keep *_offlineBeamSpot_*_*', 
        'keep *_TriggerResults_*_*', 
        'keep *_eventCount_*_*', 
        'keep *_weightsCount_*_*', 
        'keep *_generator_*_*', 
        'keep *_slimmedGenJets_*_*', 
        'keep *_flashggDiPhotons_*_*', 
        'keep *_addPileupInfo_*_*', 
        'keep *GsfElectronCore*_*_*_*', 
        'keep *_flashggSelected*_*_*', 
        'drop *_flashgg*Jet*_*_*', 
        'drop *_flashggMuons_*_*', 
        'drop *_flashggElectrons_*_*', 
        'keep *_flashggFinalJets_*_*', 
        'keep *_flashggFinalPuppiJets_*_*', 
        'keep *_flashgg*_*_*')
)


process.flashggTagSequence = cms.Sequence(process.flashggDiPhotonMVA+process.flashggDiPhotonMVANew+process.flashggDiPhotonMVAPUPPI+process.flashggUnpackedJets+process.flashggUnpackedPuppiJets+process.flashggVBFMVA+process.flashggVBFMVANew+process.flashggVBFMVAPUPPI+process.flashggVBFDiPhoDiJetMVA+process.flashggVBFDiPhoDiJetMVANew+process.flashggVBFDiPhoDiJetMVAPUPPI+process.flashggUntagged+process.flashggVBFTag+process.flashggTTHLeptonicTag+process.flashggVHEtTag+process.flashggTTHHadronicTag+process.flashggVHLooseTag+process.flashggVHTightTag+process.flashggVHHadronicTag+process.flashggTagSorter)


process.MessageLogger = cms.Service("MessageLogger",
    FrameworkJobReport = cms.untracked.PSet(
        FwkJob = cms.untracked.PSet(
            limit = cms.untracked.int32(10000000),
            optionalPSet = cms.untracked.bool(True)
        ),
        default = cms.untracked.PSet(
            limit = cms.untracked.int32(0)
        ),
        optionalPSet = cms.untracked.bool(True)
    ),
    categories = cms.untracked.vstring('FwkJob', 
        'FwkReport', 
        'FwkSummary', 
        'Root_NoDictionary'),
    cerr = cms.untracked.PSet(
        FwkJob = cms.untracked.PSet(
            limit = cms.untracked.int32(0),
            optionalPSet = cms.untracked.bool(True)
        ),
        FwkReport = cms.untracked.PSet(
            limit = cms.untracked.int32(10000000),
            optionalPSet = cms.untracked.bool(True),
            reportEvery = cms.untracked.int32(1)
        ),
        FwkSummary = cms.untracked.PSet(
            limit = cms.untracked.int32(10000000),
            optionalPSet = cms.untracked.bool(True),
            reportEvery = cms.untracked.int32(1)
        ),
        INFO = cms.untracked.PSet(
            limit = cms.untracked.int32(0)
        ),
        Root_NoDictionary = cms.untracked.PSet(
            limit = cms.untracked.int32(0),
            optionalPSet = cms.untracked.bool(True)
        ),
        default = cms.untracked.PSet(
            limit = cms.untracked.int32(10000000)
        ),
        noTimeStamps = cms.untracked.bool(False),
        optionalPSet = cms.untracked.bool(True),
        threshold = cms.untracked.string('INFO')
    ),
    cerr_stats = cms.untracked.PSet(
        optionalPSet = cms.untracked.bool(True),
        output = cms.untracked.string('cerr'),
        threshold = cms.untracked.string('WARNING')
    ),
    cout = cms.untracked.PSet(
        placeholder = cms.untracked.bool(True)
    ),
    debugModules = cms.untracked.vstring(),
    debugs = cms.untracked.PSet(
        placeholder = cms.untracked.bool(True)
    ),
    default = cms.untracked.PSet(

    ),
    destinations = cms.untracked.vstring('warnings', 
        'errors', 
        'infos', 
        'debugs', 
        'cout', 
        'cerr'),
    errors = cms.untracked.PSet(
        placeholder = cms.untracked.bool(True)
    ),
    fwkJobReports = cms.untracked.vstring('FrameworkJobReport'),
    infos = cms.untracked.PSet(
        Root_NoDictionary = cms.untracked.PSet(
            limit = cms.untracked.int32(0),
            optionalPSet = cms.untracked.bool(True)
        ),
        optionalPSet = cms.untracked.bool(True),
        placeholder = cms.untracked.bool(True)
    ),
    statistics = cms.untracked.vstring('cerr_stats'),
    suppressDebug = cms.untracked.vstring(),
    suppressInfo = cms.untracked.vstring(),
    suppressWarning = cms.untracked.vstring(),
    warnings = cms.untracked.PSet(
        placeholder = cms.untracked.bool(True)
    )
)


process.TFileService = cms.Service("TFileService",
    closeFileFast = cms.untracked.bool(True),
    fileName = cms.string('/home/hep/yhaddad/work/CMSSW_7_4_12/src/flashgg/Taggers/test/MVATraining/test_diphodijet_pfchs_training/output_VBFHToGG_M-125_13TeV_powheg_pythia8_numEvent5000_histos.root')
)


process.CSCGeometryESModule = cms.ESProducer("CSCGeometryESModule",
    alignmentsLabel = cms.string(''),
    appendToDataLabel = cms.string(''),
    applyAlignment = cms.bool(True),
    debugV = cms.untracked.bool(False),
    useCentreTIOffsets = cms.bool(False),
    useDDD = cms.bool(False),
    useGangedStripsInME1a = cms.bool(True),
    useOnlyWiresInME1a = cms.bool(False),
    useRealWireGeometry = cms.bool(True)
)


process.CaloGeometryBuilder = cms.ESProducer("CaloGeometryBuilder",
    SelectedCalos = cms.vstring('HCAL', 
        'ZDC', 
        'CASTOR', 
        'EcalBarrel', 
        'EcalEndcap', 
        'EcalPreshower', 
        'TOWER')
)


process.CaloTopologyBuilder = cms.ESProducer("CaloTopologyBuilder")


process.CaloTowerGeometryFromDBEP = cms.ESProducer("CaloTowerGeometryFromDBEP",
    applyAlignment = cms.bool(False),
    hcalTopologyConstants = cms.PSet(
        maxDepthHB = cms.int32(2),
        maxDepthHE = cms.int32(3),
        mode = cms.string('HcalTopologyMode::LHC')
    )
)


process.CastorDbProducer = cms.ESProducer("CastorDbProducer")


process.CastorGeometryFromDBEP = cms.ESProducer("CastorGeometryFromDBEP",
    applyAlignment = cms.bool(False)
)


process.DTGeometryESModule = cms.ESProducer("DTGeometryESModule",
    alignmentsLabel = cms.string(''),
    appendToDataLabel = cms.string(''),
    applyAlignment = cms.bool(True),
    fromDDD = cms.bool(False)
)


process.EcalBarrelGeometryFromDBEP = cms.ESProducer("EcalBarrelGeometryFromDBEP",
    applyAlignment = cms.bool(True)
)


process.EcalElectronicsMappingBuilder = cms.ESProducer("EcalElectronicsMappingBuilder")


process.EcalEndcapGeometryFromDBEP = cms.ESProducer("EcalEndcapGeometryFromDBEP",
    applyAlignment = cms.bool(True)
)


process.EcalLaserCorrectionService = cms.ESProducer("EcalLaserCorrectionService")


process.EcalPreshowerGeometryFromDBEP = cms.ESProducer("EcalPreshowerGeometryFromDBEP",
    applyAlignment = cms.bool(True)
)


process.EcalTrigTowerConstituentsMapBuilder = cms.ESProducer("EcalTrigTowerConstituentsMapBuilder",
    MapFile = cms.untracked.string('Geometry/EcalMapping/data/EndCap_TTMap.txt')
)


process.GlobalTrackingGeometryESProducer = cms.ESProducer("GlobalTrackingGeometryESProducer")


process.HcalAlignmentEP = cms.ESProducer("HcalAlignmentEP")


process.HcalGeometryFromDBEP = cms.ESProducer("HcalGeometryFromDBEP",
    applyAlignment = cms.bool(True),
    hcalTopologyConstants = cms.PSet(
        maxDepthHB = cms.int32(2),
        maxDepthHE = cms.int32(3),
        mode = cms.string('HcalTopologyMode::LHC')
    )
)


process.MuonDetLayerGeometryESProducer = cms.ESProducer("MuonDetLayerGeometryESProducer")


process.MuonNumberingInitialization = cms.ESProducer("MuonNumberingInitialization")


process.ParabolicParametrizedMagneticFieldProducer = cms.ESProducer("AutoParametrizedMagneticFieldProducer",
    label = cms.untracked.string('ParabolicMf'),
    valueOverride = cms.int32(-1),
    version = cms.string('Parabolic')
)


process.RPCGeometryESModule = cms.ESProducer("RPCGeometryESModule",
    compatibiltyWith11 = cms.untracked.bool(True),
    useDDD = cms.untracked.bool(False)
)


process.SiStripRecHitMatcherESProducer = cms.ESProducer("SiStripRecHitMatcherESProducer",
    ComponentName = cms.string('StandardMatcher'),
    NSigmaInside = cms.double(3.0),
    PreFilter = cms.bool(False)
)


process.StripCPEfromTrackAngleESProducer = cms.ESProducer("StripCPEESProducer",
    ComponentName = cms.string('StripCPEfromTrackAngle'),
    ComponentType = cms.string('StripCPEfromTrackAngle'),
    parameters = cms.PSet(
        mLC_P0 = cms.double(-0.326),
        mLC_P1 = cms.double(0.618),
        mLC_P2 = cms.double(0.3),
        mTEC_P0 = cms.double(-1.885),
        mTEC_P1 = cms.double(0.471),
        mTIB_P0 = cms.double(-0.742),
        mTIB_P1 = cms.double(0.202),
        mTID_P0 = cms.double(-1.427),
        mTID_P1 = cms.double(0.433),
        mTOB_P0 = cms.double(-1.026),
        mTOB_P1 = cms.double(0.253),
        maxChgOneMIP = cms.double(6000.0),
        useLegacyError = cms.bool(False)
    )
)


process.TrackerRecoGeometryESProducer = cms.ESProducer("TrackerRecoGeometryESProducer")


process.VolumeBasedMagneticFieldESProducer = cms.ESProducer("VolumeBasedMagneticFieldESProducerFromDB",
    debugBuilder = cms.untracked.bool(False),
    label = cms.untracked.string(''),
    valueOverride = cms.int32(-1)
)


process.XMLFromDBSource = cms.ESProducer("XMLIdealGeometryESProducer",
    label = cms.string('Extended'),
    rootDDName = cms.string('cms:OCMS')
)


process.ZdcGeometryFromDBEP = cms.ESProducer("ZdcGeometryFromDBEP",
    applyAlignment = cms.bool(False)
)


process.fakeForIdealAlignment = cms.ESProducer("FakeAlignmentProducer",
    appendToDataLabel = cms.string('fakeForIdeal')
)


process.hcalTopologyIdeal = cms.ESProducer("HcalTopologyIdealEP",
    Exclude = cms.untracked.string(''),
    appendToDataLabel = cms.string(''),
    hcalTopologyConstants = cms.PSet(
        maxDepthHB = cms.int32(2),
        maxDepthHE = cms.int32(3),
        mode = cms.string('HcalTopologyMode::LHC')
    )
)


process.hcal_db_producer = cms.ESProducer("HcalDbProducer",
    dump = cms.untracked.vstring(''),
    file = cms.untracked.string('')
)


process.idealForDigiCSCGeometry = cms.ESProducer("CSCGeometryESModule",
    alignmentsLabel = cms.string('fakeForIdeal'),
    appendToDataLabel = cms.string('idealForDigi'),
    applyAlignment = cms.bool(False),
    debugV = cms.untracked.bool(False),
    useCentreTIOffsets = cms.bool(False),
    useDDD = cms.bool(False),
    useGangedStripsInME1a = cms.bool(True),
    useOnlyWiresInME1a = cms.bool(False),
    useRealWireGeometry = cms.bool(True)
)


process.idealForDigiDTGeometry = cms.ESProducer("DTGeometryESModule",
    alignmentsLabel = cms.string('fakeForIdeal'),
    appendToDataLabel = cms.string('idealForDigi'),
    applyAlignment = cms.bool(False),
    fromDDD = cms.bool(False)
)


process.idealForDigiTrackerGeometry = cms.ESProducer("TrackerDigiGeometryESModule",
    alignmentsLabel = cms.string('fakeForIdeal'),
    appendToDataLabel = cms.string('idealForDigi'),
    applyAlignment = cms.bool(False),
    fromDDD = cms.bool(False),
    trackerGeometryConstants = cms.PSet(
        BIG_PIX_PER_ROC_X = cms.int32(1),
        BIG_PIX_PER_ROC_Y = cms.int32(2),
        COLS_PER_ROC = cms.int32(52),
        ROCS_X = cms.int32(0),
        ROCS_Y = cms.int32(0),
        ROWS_PER_ROC = cms.int32(80),
        upgradeGeometry = cms.bool(False)
    )
)


process.siPixelQualityESProducer = cms.ESProducer("SiPixelQualityESProducer",
    ListOfRecordToMerge = cms.VPSet(cms.PSet(
        record = cms.string('SiPixelQualityFromDbRcd'),
        tag = cms.string('')
    ), 
        cms.PSet(
            record = cms.string('SiPixelDetVOffRcd'),
            tag = cms.string('')
        ))
)


process.siStripBackPlaneCorrectionDepESProducer = cms.ESProducer("SiStripBackPlaneCorrectionDepESProducer",
    BackPlaneCorrectionDeconvMode = cms.PSet(
        label = cms.untracked.string('deconvolution'),
        record = cms.string('SiStripBackPlaneCorrectionRcd')
    ),
    BackPlaneCorrectionPeakMode = cms.PSet(
        label = cms.untracked.string('peak'),
        record = cms.string('SiStripBackPlaneCorrectionRcd')
    ),
    LatencyRecord = cms.PSet(
        label = cms.untracked.string(''),
        record = cms.string('SiStripLatencyRcd')
    )
)


process.siStripGainESProducer = cms.ESProducer("SiStripGainESProducer",
    APVGain = cms.VPSet(cms.PSet(
        Label = cms.untracked.string(''),
        NormalizationFactor = cms.untracked.double(1.0),
        Record = cms.string('SiStripApvGainRcd')
    ), 
        cms.PSet(
            Label = cms.untracked.string(''),
            NormalizationFactor = cms.untracked.double(1.0),
            Record = cms.string('SiStripApvGain2Rcd')
        )),
    AutomaticNormalization = cms.bool(False),
    appendToDataLabel = cms.string(''),
    printDebug = cms.untracked.bool(False)
)


process.siStripLorentzAngleDepESProducer = cms.ESProducer("SiStripLorentzAngleDepESProducer",
    LatencyRecord = cms.PSet(
        label = cms.untracked.string(''),
        record = cms.string('SiStripLatencyRcd')
    ),
    LorentzAngleDeconvMode = cms.PSet(
        label = cms.untracked.string('deconvolution'),
        record = cms.string('SiStripLorentzAngleRcd')
    ),
    LorentzAnglePeakMode = cms.PSet(
        label = cms.untracked.string('peak'),
        record = cms.string('SiStripLorentzAngleRcd')
    )
)


process.siStripQualityESProducer = cms.ESProducer("SiStripQualityESProducer",
    ListOfRecordToMerge = cms.VPSet(cms.PSet(
        record = cms.string('SiStripDetVOffRcd'),
        tag = cms.string('')
    ), 
        cms.PSet(
            record = cms.string('SiStripDetCablingRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('RunInfoRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiStripBadChannelRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiStripBadFiberRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiStripBadModuleRcd'),
            tag = cms.string('')
        ), 
        cms.PSet(
            record = cms.string('SiStripBadStripRcd'),
            tag = cms.string('')
        )),
    PrintDebugOutput = cms.bool(False),
    ReduceGranularity = cms.bool(False),
    ThresholdForReducedGranularity = cms.double(0.3),
    UseEmptyRunInfo = cms.bool(False),
    appendToDataLabel = cms.string('')
)


process.sistripconn = cms.ESProducer("SiStripConnectivity")


process.stripCPEESProducer = cms.ESProducer("StripCPEESProducer",
    ComponentName = cms.string('stripCPE'),
    ComponentType = cms.string('SimpleStripCPE'),
    parameters = cms.PSet(

    )
)


process.trackerGeometryDB = cms.ESProducer("TrackerDigiGeometryESModule",
    alignmentsLabel = cms.string(''),
    appendToDataLabel = cms.string(''),
    applyAlignment = cms.bool(True),
    fromDDD = cms.bool(False),
    trackerGeometryConstants = cms.PSet(
        BIG_PIX_PER_ROC_X = cms.int32(1),
        BIG_PIX_PER_ROC_Y = cms.int32(2),
        COLS_PER_ROC = cms.int32(52),
        ROCS_X = cms.int32(0),
        ROCS_Y = cms.int32(0),
        ROWS_PER_ROC = cms.int32(80),
        upgradeGeometry = cms.bool(False)
    )
)


process.trackerNumberingGeometryDB = cms.ESProducer("TrackerGeometricDetESModule",
    appendToDataLabel = cms.string(''),
    fromDDD = cms.bool(False)
)


process.trackerTopologyConstants = cms.ESProducer("TrackerTopologyEP",
    appendToDataLabel = cms.string(''),
    pxb_ladderMask = cms.uint32(255),
    pxb_ladderStartBit = cms.uint32(8),
    pxb_layerMask = cms.uint32(15),
    pxb_layerStartBit = cms.uint32(16),
    pxb_moduleMask = cms.uint32(63),
    pxb_moduleStartBit = cms.uint32(2),
    pxf_bladeMask = cms.uint32(63),
    pxf_bladeStartBit = cms.uint32(10),
    pxf_diskMask = cms.uint32(15),
    pxf_diskStartBit = cms.uint32(16),
    pxf_moduleMask = cms.uint32(63),
    pxf_moduleStartBit = cms.uint32(2),
    pxf_panelMask = cms.uint32(3),
    pxf_panelStartBit = cms.uint32(8),
    pxf_sideMask = cms.uint32(3),
    pxf_sideStartBit = cms.uint32(23),
    tec_moduleMask = cms.uint32(7),
    tec_moduleStartBit = cms.uint32(2),
    tec_petalMask = cms.uint32(15),
    tec_petalStartBit = cms.uint32(8),
    tec_petal_fw_bwMask = cms.uint32(3),
    tec_petal_fw_bwStartBit = cms.uint32(12),
    tec_ringMask = cms.uint32(7),
    tec_ringStartBit = cms.uint32(5),
    tec_sideMask = cms.uint32(3),
    tec_sideStartBit = cms.uint32(18),
    tec_sterMask = cms.uint32(3),
    tec_sterStartBit = cms.uint32(0),
    tec_wheelMask = cms.uint32(15),
    tec_wheelStartBit = cms.uint32(14),
    tib_layerMask = cms.uint32(7),
    tib_layerStartBit = cms.uint32(14),
    tib_moduleMask = cms.uint32(3),
    tib_moduleStartBit = cms.uint32(2),
    tib_sterMask = cms.uint32(3),
    tib_sterStartBit = cms.uint32(0),
    tib_strMask = cms.uint32(63),
    tib_strStartBit = cms.uint32(4),
    tib_str_fw_bwMask = cms.uint32(3),
    tib_str_fw_bwStartBit = cms.uint32(12),
    tib_str_int_extMask = cms.uint32(3),
    tib_str_int_extStartBit = cms.uint32(10),
    tid_moduleMask = cms.uint32(31),
    tid_moduleStartBit = cms.uint32(2),
    tid_module_fw_bwMask = cms.uint32(3),
    tid_module_fw_bwStartBit = cms.uint32(7),
    tid_ringMask = cms.uint32(3),
    tid_ringStartBit = cms.uint32(9),
    tid_sideMask = cms.uint32(3),
    tid_sideStartBit = cms.uint32(13),
    tid_sterMask = cms.uint32(3),
    tid_sterStartBit = cms.uint32(0),
    tid_wheelMask = cms.uint32(3),
    tid_wheelStartBit = cms.uint32(11),
    tob_layerMask = cms.uint32(7),
    tob_layerStartBit = cms.uint32(14),
    tob_moduleMask = cms.uint32(7),
    tob_moduleStartBit = cms.uint32(2),
    tob_rodMask = cms.uint32(127),
    tob_rodStartBit = cms.uint32(5),
    tob_rod_fw_bwMask = cms.uint32(3),
    tob_rod_fw_bwStartBit = cms.uint32(12),
    tob_sterMask = cms.uint32(3),
    tob_sterStartBit = cms.uint32(0)
)


process.GlobalTag = cms.ESSource("PoolDBESSource",
    BlobStreamerName = cms.untracked.string('TBufferBlobStreamingService'),
    DBParameters = cms.PSet(
        authenticationPath = cms.untracked.string(''),
        authenticationSystem = cms.untracked.int32(0),
        connectionRetrialPeriod = cms.untracked.int32(10),
        connectionRetrialTimeOut = cms.untracked.int32(60),
        connectionTimeOut = cms.untracked.int32(60),
        enableConnectionSharing = cms.untracked.bool(True),
        enablePoolAutomaticCleanUp = cms.untracked.bool(False),
        enableReadOnlySessionOnUpdateConnection = cms.untracked.bool(False),
        idleConnectionCleanupPeriod = cms.untracked.int32(10),
        messageLevel = cms.untracked.int32(0)
    ),
    connect = cms.string('frontier://FrontierProd/CMS_COND_31X_GLOBALTAG'),
    globaltag = cms.string('MCRUN2_74_V9::All'),
    toGet = cms.VPSet()
)


process.eegeom = cms.ESSource("EmptyESSource",
    firstValid = cms.vuint32(1),
    iovIsRunNotTime = cms.bool(True),
    recordName = cms.string('EcalMappingRcd')
)


process.es_hardcode = cms.ESSource("HcalHardcodeCalibrations",
    GainWidthsForTrigPrims = cms.bool(False),
    HERecalibration = cms.bool(False),
    HEreCalibCutoff = cms.double(20.0),
    HFRecalibration = cms.bool(False),
    HcalReLabel = cms.PSet(
        RelabelHits = cms.untracked.bool(False),
        RelabelRules = cms.untracked.PSet(
            CorrectPhi = cms.untracked.bool(False),
            Eta1 = cms.untracked.vint32(1, 2, 2, 2, 3, 
                3, 3, 3, 3, 3, 
                3, 3, 3, 3, 3, 
                3, 3, 3, 3),
            Eta16 = cms.untracked.vint32(1, 1, 2, 2, 2, 
                2, 2, 2, 2, 3, 
                3, 3, 3, 3, 3, 
                3, 3, 3, 3),
            Eta17 = cms.untracked.vint32(1, 1, 2, 2, 3, 
                3, 3, 4, 4, 4, 
                4, 4, 5, 5, 5, 
                5, 5, 5, 5)
        )
    ),
    hcalTopologyConstants = cms.PSet(
        maxDepthHB = cms.int32(2),
        maxDepthHE = cms.int32(3),
        mode = cms.string('HcalTopologyMode::LHC')
    ),
    iLumi = cms.double(-1.0),
    toGet = cms.untracked.vstring('GainWidths')
)


process.prefer("es_hardcode")

process.CondDBSetup = cms.PSet(
    DBParameters = cms.PSet(
        authenticationPath = cms.untracked.string(''),
        authenticationSystem = cms.untracked.int32(0),
        connectionRetrialPeriod = cms.untracked.int32(10),
        connectionRetrialTimeOut = cms.untracked.int32(60),
        connectionTimeOut = cms.untracked.int32(60),
        enableConnectionSharing = cms.untracked.bool(True),
        enablePoolAutomaticCleanUp = cms.untracked.bool(False),
        enableReadOnlySessionOnUpdateConnection = cms.untracked.bool(False),
        idleConnectionCleanupPeriod = cms.untracked.int32(10),
        messageLevel = cms.untracked.int32(0)
    )
)

process.HcalReLabel = cms.PSet(
    RelabelHits = cms.untracked.bool(False),
    RelabelRules = cms.untracked.PSet(
        CorrectPhi = cms.untracked.bool(False),
        Eta1 = cms.untracked.vint32(1, 2, 2, 2, 3, 
            3, 3, 3, 3, 3, 
            3, 3, 3, 3, 3, 
            3, 3, 3, 3),
        Eta16 = cms.untracked.vint32(1, 1, 2, 2, 2, 
            2, 2, 2, 2, 3, 
            3, 3, 3, 3, 3, 
            3, 3, 3, 3),
        Eta17 = cms.untracked.vint32(1, 1, 2, 2, 3, 
            3, 3, 4, 4, 4, 
            4, 4, 5, 5, 5, 
            5, 5, 5, 5)
    )
)

process.VBFDiPhoDiJetMVATrainingDumpConfNew = cms.PSet(
    categories = cms.VPSet(),
    className = cms.untracked.string('CutBasedVBFDiPhoDiJetMVAResultDumper'),
    classifierCfg = cms.PSet(
        categories = cms.VPSet()
    ),
    dumpGlobalVariables = cms.untracked.bool(True),
    dumpHistos = cms.untracked.bool(True),
    dumpTrees = cms.untracked.bool(False),
    dumpWorkspace = cms.untracked.bool(False),
    generatorInfo = cms.InputTag("generator"),
    globalVariables = cms.PSet(
        rho = cms.InputTag("fixedGridRhoAll"),
        vertexes = cms.InputTag("offlineSlimmedPrimaryVertices")
    ),
    lumiWeight = cms.double(0.01709088),
    maxCandPerEvent = cms.int32(1),
    nameTemplate = cms.untracked.string('$PROCESS_$SQRTS_$LABEL_$SUBCAT'),
    processId = cms.string('vbf_m125'),
    quietRooFit = cms.untracked.bool(False),
    src = cms.InputTag("flashggVBFDiPhoDiJetMVANew"),
    workspaceName = cms.untracked.string('cms_hgg_$SQRTS')
)

process.VBFMVATrainingDumpConfNew = cms.PSet(
    categories = cms.VPSet(),
    className = cms.untracked.string('CutBasedVBFMVAResultDumper'),
    classifierCfg = cms.PSet(
        categories = cms.VPSet()
    ),
    dumpGlobalVariables = cms.untracked.bool(True),
    dumpHistos = cms.untracked.bool(True),
    dumpTrees = cms.untracked.bool(False),
    dumpWorkspace = cms.untracked.bool(False),
    generatorInfo = cms.InputTag("generator"),
    globalVariables = cms.PSet(
        rho = cms.InputTag("fixedGridRhoAll"),
        vertexes = cms.InputTag("offlineSlimmedPrimaryVertices")
    ),
    lumiWeight = cms.double(0.01709088),
    maxCandPerEvent = cms.int32(1),
    nameTemplate = cms.untracked.string('$PROCESS_$SQRTS_$LABEL_$SUBCAT'),
    processId = cms.string('vbf_m125'),
    quietRooFit = cms.untracked.bool(False),
    src = cms.InputTag("flashggVBFMVANew"),
    workspaceName = cms.untracked.string('cms_hgg_$SQRTS')
)

process.maxEvents = cms.untracked.PSet(
    input = cms.untracked.int32(5000)
)

