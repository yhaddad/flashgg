import FWCore.ParameterSet.Config as cms

process = cms.Process("VBFTagsDumper")

process.source = cms.Source("PoolSource",
    fileNames = cms.untracked.vstring('root://eoscms//eos/cms/store/group/phys_higgs/cmshgg/sethzenz/flashgg/RunIISpring15-ReMiniAOD-BetaV7-25ns/Spring15BetaV7/QCD_Pt-30to40_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8/RunIISpring15-ReMiniAOD-BetaV7-25ns-Spring15BetaV7-v0-RunIISpring15MiniAODv2-74X_mcRun2_asymptotic_v2-v1/151021_152339/0000/myMicroAODOutputFile_10.root', 
        'root://eoscms//eos/cms/store/group/phys_higgs/cmshgg/sethzenz/flashgg/RunIISpring15-ReMiniAOD-BetaV7-25ns/Spring15BetaV7/QCD_Pt-30to40_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8/RunIISpring15-ReMiniAOD-BetaV7-25ns-Spring15BetaV7-v0-RunIISpring15MiniAODv2-74X_mcRun2_asymptotic_v2-v1/151021_152339/0000/myMicroAODOutputFile_11.root', 
        'root://eoscms//eos/cms/store/group/phys_higgs/cmshgg/sethzenz/flashgg/RunIISpring15-ReMiniAOD-BetaV7-25ns/Spring15BetaV7/QCD_Pt-30to40_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8/RunIISpring15-ReMiniAOD-BetaV7-25ns-Spring15BetaV7-v0-RunIISpring15MiniAODv2-74X_mcRun2_asymptotic_v2-v1/151021_152339/0000/myMicroAODOutputFile_12.root', 
        'root://eoscms//eos/cms/store/group/phys_higgs/cmshgg/sethzenz/flashgg/RunIISpring15-ReMiniAOD-BetaV7-25ns/Spring15BetaV7/QCD_Pt-30to40_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8/RunIISpring15-ReMiniAOD-BetaV7-25ns-Spring15BetaV7-v0-RunIISpring15MiniAODv2-74X_mcRun2_asymptotic_v2-v1/151021_152339/0000/myMicroAODOutputFile_13.root', 
        'root://eoscms//eos/cms/store/group/phys_higgs/cmshgg/sethzenz/flashgg/RunIISpring15-ReMiniAOD-BetaV7-25ns/Spring15BetaV7/QCD_Pt-30to40_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8/RunIISpring15-ReMiniAOD-BetaV7-25ns-Spring15BetaV7-v0-RunIISpring15MiniAODv2-74X_mcRun2_asymptotic_v2-v1/151021_152339/0000/myMicroAODOutputFile_14.root', 
        'root://eoscms//eos/cms/store/group/phys_higgs/cmshgg/sethzenz/flashgg/RunIISpring15-ReMiniAOD-BetaV7-25ns/Spring15BetaV7/QCD_Pt-30to40_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8/RunIISpring15-ReMiniAOD-BetaV7-25ns-Spring15BetaV7-v0-RunIISpring15MiniAODv2-74X_mcRun2_asymptotic_v2-v1/151021_152339/0000/myMicroAODOutputFile_15.root', 
        'root://eoscms//eos/cms/store/group/phys_higgs/cmshgg/sethzenz/flashgg/RunIISpring15-ReMiniAOD-BetaV7-25ns/Spring15BetaV7/QCD_Pt-30to40_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8/RunIISpring15-ReMiniAOD-BetaV7-25ns-Spring15BetaV7-v0-RunIISpring15MiniAODv2-74X_mcRun2_asymptotic_v2-v1/151021_152339/0000/myMicroAODOutputFile_16.root', 
        'root://eoscms//eos/cms/store/group/phys_higgs/cmshgg/sethzenz/flashgg/RunIISpring15-ReMiniAOD-BetaV7-25ns/Spring15BetaV7/QCD_Pt-30to40_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8/RunIISpring15-ReMiniAOD-BetaV7-25ns-Spring15BetaV7-v0-RunIISpring15MiniAODv2-74X_mcRun2_asymptotic_v2-v1/151021_152339/0000/myMicroAODOutputFile_17.root', 
        'root://eoscms//eos/cms/store/group/phys_higgs/cmshgg/sethzenz/flashgg/RunIISpring15-ReMiniAOD-BetaV7-25ns/Spring15BetaV7/QCD_Pt-30to40_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8/RunIISpring15-ReMiniAOD-BetaV7-25ns-Spring15BetaV7-v0-RunIISpring15MiniAODv2-74X_mcRun2_asymptotic_v2-v1/151021_152339/0000/myMicroAODOutputFile_18.root', 
        'root://eoscms//eos/cms/store/group/phys_higgs/cmshgg/sethzenz/flashgg/RunIISpring15-ReMiniAOD-BetaV7-25ns/Spring15BetaV7/QCD_Pt-30to40_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8/RunIISpring15-ReMiniAOD-BetaV7-25ns-Spring15BetaV7-v0-RunIISpring15MiniAODv2-74X_mcRun2_asymptotic_v2-v1/151021_152339/0000/myMicroAODOutputFile_19.root', 
        'root://eoscms//eos/cms/store/group/phys_higgs/cmshgg/sethzenz/flashgg/RunIISpring15-ReMiniAOD-BetaV7-25ns/Spring15BetaV7/QCD_Pt-30to40_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8/RunIISpring15-ReMiniAOD-BetaV7-25ns-Spring15BetaV7-v0-RunIISpring15MiniAODv2-74X_mcRun2_asymptotic_v2-v1/151021_152339/0000/myMicroAODOutputFile_2.root', 
        'root://eoscms//eos/cms/store/group/phys_higgs/cmshgg/sethzenz/flashgg/RunIISpring15-ReMiniAOD-BetaV7-25ns/Spring15BetaV7/QCD_Pt-30to40_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8/RunIISpring15-ReMiniAOD-BetaV7-25ns-Spring15BetaV7-v0-RunIISpring15MiniAODv2-74X_mcRun2_asymptotic_v2-v1/151021_152339/0000/myMicroAODOutputFile_20.root', 
        'root://eoscms//eos/cms/store/group/phys_higgs/cmshgg/sethzenz/flashgg/RunIISpring15-ReMiniAOD-BetaV7-25ns/Spring15BetaV7/QCD_Pt-30to40_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8/RunIISpring15-ReMiniAOD-BetaV7-25ns-Spring15BetaV7-v0-RunIISpring15MiniAODv2-74X_mcRun2_asymptotic_v2-v1/151021_152339/0000/myMicroAODOutputFile_21.root', 
        'root://eoscms//eos/cms/store/group/phys_higgs/cmshgg/sethzenz/flashgg/RunIISpring15-ReMiniAOD-BetaV7-25ns/Spring15BetaV7/QCD_Pt-30to40_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8/RunIISpring15-ReMiniAOD-BetaV7-25ns-Spring15BetaV7-v0-RunIISpring15MiniAODv2-74X_mcRun2_asymptotic_v2-v1/151021_152339/0000/myMicroAODOutputFile_22.root', 
        'root://eoscms//eos/cms/store/group/phys_higgs/cmshgg/sethzenz/flashgg/RunIISpring15-ReMiniAOD-BetaV7-25ns/Spring15BetaV7/QCD_Pt-30to40_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8/RunIISpring15-ReMiniAOD-BetaV7-25ns-Spring15BetaV7-v0-RunIISpring15MiniAODv2-74X_mcRun2_asymptotic_v2-v1/151021_152339/0000/myMicroAODOutputFile_6.root', 
        'root://eoscms//eos/cms/store/group/phys_higgs/cmshgg/sethzenz/flashgg/RunIISpring15-ReMiniAOD-BetaV7-25ns/Spring15BetaV7/QCD_Pt-30to40_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8/RunIISpring15-ReMiniAOD-BetaV7-25ns-Spring15BetaV7-v0-RunIISpring15MiniAODv2-74X_mcRun2_asymptotic_v2-v1/151021_152339/0000/myMicroAODOutputFile_7.root', 
        'root://eoscms//eos/cms/store/group/phys_higgs/cmshgg/sethzenz/flashgg/RunIISpring15-ReMiniAOD-BetaV7-25ns/Spring15BetaV7/QCD_Pt-30to40_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8/RunIISpring15-ReMiniAOD-BetaV7-25ns-Spring15BetaV7-v0-RunIISpring15MiniAODv2-74X_mcRun2_asymptotic_v2-v1/151021_152339/0000/myMicroAODOutputFile_8.root', 
        'root://eoscms//eos/cms/store/group/phys_higgs/cmshgg/sethzenz/flashgg/RunIISpring15-ReMiniAOD-BetaV7-25ns/Spring15BetaV7/QCD_Pt-30to40_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8/RunIISpring15-ReMiniAOD-BetaV7-25ns-Spring15BetaV7-v0-RunIISpring15MiniAODv2-74X_mcRun2_asymptotic_v2-v1/151021_152339/0000/myMicroAODOutputFile_9.root', 
        'root://eoscms//eos/cms/store/group/phys_higgs/cmshgg/sethzenz/flashgg/RunIISpring15-ReMiniAOD-BetaV7-25ns/Spring15BetaV7/QCD_Pt-30to40_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8/RunIISpring15-ReMiniAOD-BetaV7-25ns-Spring15BetaV7-v0-RunIISpring15MiniAODv2-74X_mcRun2_asymptotic_v2-v1/151021_152339/0000/myMicroAODOutputFile_1.root', 
        'root://eoscms//eos/cms/store/group/phys_higgs/cmshgg/sethzenz/flashgg/RunIISpring15-ReMiniAOD-BetaV7-25ns/Spring15BetaV7/QCD_Pt-30to40_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8/RunIISpring15-ReMiniAOD-BetaV7-25ns-Spring15BetaV7-v0-RunIISpring15MiniAODv2-74X_mcRun2_asymptotic_v2-v1/151021_152339/0000/myMicroAODOutputFile_3.root', 
        'root://eoscms//eos/cms/store/group/phys_higgs/cmshgg/sethzenz/flashgg/RunIISpring15-ReMiniAOD-BetaV7-25ns/Spring15BetaV7/QCD_Pt-30to40_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8/RunIISpring15-ReMiniAOD-BetaV7-25ns-Spring15BetaV7-v0-RunIISpring15MiniAODv2-74X_mcRun2_asymptotic_v2-v1/151021_152339/0000/myMicroAODOutputFile_4.root', 
        'root://eoscms//eos/cms/store/group/phys_higgs/cmshgg/sethzenz/flashgg/RunIISpring15-ReMiniAOD-BetaV7-25ns/Spring15BetaV7/QCD_Pt-30to40_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8/RunIISpring15-ReMiniAOD-BetaV7-25ns-Spring15BetaV7-v0-RunIISpring15MiniAODv2-74X_mcRun2_asymptotic_v2-v1/151021_152339/0000/myMicroAODOutputFile_5.root')
)
process.flashggDiPhotonMVA = cms.EDProducer("FlashggDiPhotonMVAProducer",
    BeamSpotTag = cms.InputTag("offlineBeamSpot"),
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    Version = cms.string('old'),
    VertexProbParamsConv = cms.vdouble(-0.049, -0.241, -0.505, -0.27),
    VertexProbParamsNoConv = cms.vdouble(-0.344, -0.091, -0.234, -0.186),
    diphotonMVAweightfile = cms.FileInPath('flashgg/Taggers/data/HggBambu_SMDipho_Oct29_rwgtptallsigevenbkg7TeV_BDTG.weights.xml')
)


process.flashggDiPhotonMVANew = cms.EDProducer("FlashggDiPhotonMVAProducer",
    BeamSpotTag = cms.InputTag("offlineBeamSpot"),
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    Version = cms.string('new'),
    VertexProbParamsConv = cms.vdouble(-0.049, -0.241, -0.505, -0.27),
    VertexProbParamsNoConv = cms.vdouble(-0.344, -0.091, -0.234, -0.186),
    diphotonMVAweightfile = cms.FileInPath('flashgg/Taggers/data/Flashgg_DiPhoton_BDTG.weights.xml')
)


process.flashggDiPhotonMVAPUPPI = cms.EDProducer("FlashggDiPhotonMVAProducer",
    BeamSpotTag = cms.InputTag("offlineBeamSpot"),
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    Version = cms.string('new'),
    VertexProbParamsConv = cms.vdouble(-0.049, -0.241, -0.505, -0.27),
    VertexProbParamsNoConv = cms.vdouble(-0.344, -0.091, -0.234, -0.186),
    diphotonMVAweightfile = cms.FileInPath('flashgg/Taggers/data/Flashgg_DiPhoton_BDTG.weights.xml')
)


process.flashggTTHHadronicTag = cms.EDProducer("FlashggTTHHadronicTagProducer",
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    SystLabel = cms.string(''),
    bDiscriminatorLoose = cms.untracked.double(0.275),
    bDiscriminatorMedium = cms.untracked.double(0.545),
    bTag = cms.untracked.string('pfCombinedInclusiveSecondaryVertexV2BJetTags'),
    bjetsNumberThreshold = cms.untracked.int32(0),
    inputTagJets = cms.VInputTag(cms.InputTag("flashggUnpackedJets","0"), cms.InputTag("flashggUnpackedJets","1"), cms.InputTag("flashggUnpackedJets","2"), cms.InputTag("flashggUnpackedJets","3"), cms.InputTag("flashggUnpackedJets","4"), 
        cms.InputTag("flashggUnpackedJets","5"), cms.InputTag("flashggUnpackedJets","6"), cms.InputTag("flashggUnpackedJets","7")),
    jetsNumberThreshold = cms.untracked.int32(4)
)


process.flashggTTHLeptonicTag = cms.EDProducer("FlashggTTHLeptonicTagProducer",
    DeltaRTrkElec = cms.untracked.double(1.0),
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    ElectronPtThreshold = cms.untracked.double(20.0),
    ElectronTag = cms.InputTag("flashggSelectedElectrons"),
    EtaCuts = cms.untracked.vdouble(1.442, 1.566, 2.5),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    HighEtaPhoThreshold = cms.untracked.double(2.5),
    LongitudinalImpactParam = cms.untracked.double(0.02),
    LowPtEtaPhoThreshold = cms.untracked.double(1.4447),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.untracked.double(-0.6),
    MidPtEtaPhoThreshold = cms.untracked.double(1.566),
    MuonTag = cms.InputTag("flashggSelectedMuons"),
    PhoMVAThreshold = cms.untracked.double(-0.2),
    PuIDCutoffThreshold = cms.untracked.double(0.8),
    SystLabel = cms.string(''),
    TransverseImpactParam = cms.untracked.double(0.2),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    Zmass_ = cms.untracked.double(91.9),
    bDiscriminator = cms.untracked.vdouble(0.275, 0.545),
    bTag = cms.untracked.string('pfCombinedInclusiveSecondaryVertexV2BJetTags'),
    bjetsNumberThreshold = cms.untracked.double(1.0),
    deltaMassElectronZThreshold_ = cms.untracked.double(10.0),
    deltaRJetLeadPhoThreshold = cms.untracked.double(0.5),
    deltaRJetLepThreshold = cms.untracked.double(0.5),
    deltaRJetSubLeadPhoThreshold = cms.untracked.double(0.5),
    deltaRLepPhoThreshold = cms.untracked.double(0.5),
    deltaRMuonJetcountThreshold = cms.untracked.double(2.0),
    deltaRPhoElectronThreshold = cms.untracked.double(1.0),
    electronIsoThreshold = cms.untracked.double(0.15),
    electronNumOfHitsThreshold = cms.untracked.double(1),
    inputTagJets = cms.VInputTag(cms.InputTag("flashggUnpackedJets","0"), cms.InputTag("flashggUnpackedJets","1"), cms.InputTag("flashggUnpackedJets","2"), cms.InputTag("flashggUnpackedJets","3"), cms.InputTag("flashggUnpackedJets","4"), 
        cms.InputTag("flashggUnpackedJets","5"), cms.InputTag("flashggUnpackedJets","6"), cms.InputTag("flashggUnpackedJets","7")),
    jetEtaThreshold = cms.untracked.double(2.4),
    jetPtThreshold = cms.untracked.double(30.0),
    jetsNumberThreshold = cms.untracked.double(2.0),
    leadPhoOverMassThreshold = cms.untracked.double(0.5),
    leptonEtaThreshold = cms.untracked.double(2.4),
    leptonPtThreshold = cms.untracked.double(20),
    muPFIsoSumRelThreshold = cms.untracked.double(0.2),
    nonTrigMVAThreshold = cms.untracked.double(0.9),
    subleadPhoOverMassThreshold = cms.untracked.double(0.25)
)


process.flashggTagSorter = cms.EDProducer("FlashggTagSorter",
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    TagPriorityRanges = cms.VPSet(cms.PSet(
        TagName = cms.InputTag("flashggVHTightTag")
    ), 
        cms.PSet(
            TagName = cms.InputTag("flashggVHLooseTag")
        ), 
        cms.PSet(
            TagName = cms.InputTag("flashggVHHadronicTag")
        ), 
        cms.PSet(
            TagName = cms.InputTag("flashggVHEtTag")
        ), 
        cms.PSet(
            TagName = cms.InputTag("flashggTTHLeptonicTag")
        ), 
        cms.PSet(
            TagName = cms.InputTag("flashggTTHHadronicTag")
        ), 
        cms.PSet(
            MaxCategory = cms.untracked.int32(0),
            MinCategory = cms.untracked.int32(0),
            TagName = cms.InputTag("flashggVBFTag")
        ), 
        cms.PSet(
            MaxCategory = cms.untracked.int32(1),
            MinCategory = cms.untracked.int32(0),
            TagName = cms.InputTag("flashggUntagged")
        ), 
        cms.PSet(
            MaxCategory = cms.untracked.int32(2),
            MinCategory = cms.untracked.int32(1),
            TagName = cms.InputTag("flashggVBFTag")
        ), 
        cms.PSet(
            MaxCategory = cms.untracked.int32(4),
            MinCategory = cms.untracked.int32(2),
            TagName = cms.InputTag("flashggUntagged")
        )),
    massCutLower = cms.untracked.double(100),
    massCutUpper = cms.untracked.double(180.0)
)


process.flashggUnpackedJets = cms.EDProducer("FlashggVectorVectorJetUnpacker",
    JetsTag = cms.InputTag("flashggFinalJets"),
    NCollections = cms.uint32(8)
)


process.flashggUnpackedPuppiJets = cms.EDProducer("FlashggVectorVectorJetUnpacker",
    JetsTag = cms.InputTag("flashggFinalPuppiJets"),
    NCollections = cms.uint32(8)
)


process.flashggUntagged = cms.EDProducer("FlashggUntaggedTagProducer",
    Boundaries = cms.untracked.vdouble(0.07, 0.31, 0.62, 0.86, 0.98),
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    SystLabel = cms.string('')
)


process.flashggVBFDiPhoDiJetMVA = cms.EDProducer("FlashggVBFDiPhoDiJetMVAProducer",
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    UseLegacyMVA = cms.untracked.bool(False),
    VBFMVAResultTag = cms.InputTag("flashggVBFMVA"),
    vbfDiPhoDiJetMVAweightfile = cms.FileInPath('flashgg/Taggers/data/Flashgg_DiPhoDiJet_BDT.weights.xml')
)


process.flashggVBFDiPhoDiJetMVALegacy = cms.EDProducer("FlashggVBFDiPhoDiJetMVAProducer",
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    UseLegacyMVA = cms.untracked.bool(True),
    VBFMVAResultTag = cms.InputTag("flashggVBFMVALegacy"),
    vbfDiPhoDiJetMVAweightfile = cms.FileInPath('flashgg/Taggers/data/TMVA_vbf_dijet_dipho_evenbkg_scaledwt50_maxdPhi_Gradient.weights.xml')
)


process.flashggVBFDiPhoDiJetMVAPUPPI = cms.EDProducer("FlashggVBFDiPhoDiJetMVAProducer",
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    UseLegacyMVA = cms.untracked.bool(False),
    VBFMVAResultTag = cms.InputTag("flashggVBFMVAPUPPI"),
    vbfDiPhoDiJetMVAweightfile = cms.FileInPath('flashgg/Taggers/data/Flashgg_DiPhoDiJet_BDT.weights.xml')
)


process.flashggVBFMVA = cms.EDProducer("FlashggVBFMVAProducer",
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    JetIDLevel = cms.untracked.string('Loose'),
    MVAMethod = cms.untracked.string('BDTG'),
    MinDijetMinv = cms.double(0.0),
    UseJetID = cms.untracked.bool(True),
    inputTagJets = cms.VInputTag(cms.InputTag("flashggUnpackedJets","0"), cms.InputTag("flashggUnpackedJets","1"), cms.InputTag("flashggUnpackedJets","2"), cms.InputTag("flashggUnpackedJets","3"), cms.InputTag("flashggUnpackedJets","4"), 
        cms.InputTag("flashggUnpackedJets","5"), cms.InputTag("flashggUnpackedJets","6"), cms.InputTag("flashggUnpackedJets","7")),
    vbfMVAweightfile = cms.FileInPath('flashgg/Taggers/test/MVATraining/weights/Flashgg_VBF_CHS_BDTG.weights.xml')
)


process.flashggVBFMVALegacy = cms.EDProducer("FlashggVBFMVALegacyProducer",
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    MinDijetMinv = cms.double(0.0),
    UseLegacyMVA = cms.untracked.bool(True),
    inputTagJets = cms.VInputTag(cms.InputTag("flashggUnpackedJets","0"), cms.InputTag("flashggUnpackedJets","1"), cms.InputTag("flashggUnpackedJets","2"), cms.InputTag("flashggUnpackedJets","3"), cms.InputTag("flashggUnpackedJets","4"), 
        cms.InputTag("flashggUnpackedJets","5"), cms.InputTag("flashggUnpackedJets","6"), cms.InputTag("flashggUnpackedJets","7")),
    vbfMVAweightfile = cms.FileInPath('flashgg/Taggers/data/TMVA_dijet_sherpa_scalewt50_2evenb_powheg200_maxdPhi_oct9_Gradient.weights.xml')
)


process.flashggVBFMVAPUPPI = cms.EDProducer("FlashggVBFMVAProducer",
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    MVAMethod = cms.untracked.string('BDTG'),
    MinDijetMinv = cms.double(0.0),
    inputTagJets = cms.VInputTag(cms.InputTag("flashggUnpackedPuppiJets","0"), cms.InputTag("flashggUnpackedPuppiJets","1"), cms.InputTag("flashggUnpackedPuppiJets","2"), cms.InputTag("flashggUnpackedPuppiJets","3"), cms.InputTag("flashggUnpackedPuppiJets","4"), 
        cms.InputTag("flashggUnpackedPuppiJets","5"), cms.InputTag("flashggUnpackedPuppiJets","6"), cms.InputTag("flashggUnpackedPuppiJets","7")),
    vbfMVAweightfile = cms.FileInPath('flashgg/Taggers/test/MVATraining/weights/Flashgg_VBF_PUPPI_BDTG.weights.xml')
)


process.flashggVBFTag = cms.EDProducer("FlashggVBFTagProducer",
    Boundaries = cms.untracked.vdouble(-2, 0, 2),
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    GenJetTag = cms.InputTag("slimmedGenJets"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    SystLabel = cms.string(''),
    VBFDiPhoDiJetMVAResultTag = cms.InputTag("flashggVBFDiPhoDiJetMVA"),
    VBFMVAResultTag = cms.InputTag("flashggVBFMVA")
)


process.flashggVHEtTag = cms.EDProducer("FlashggVHEtTagProducer",
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    METTag = cms.InputTag("slimmedMETs"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    SystLabel = cms.string('')
)


process.flashggVHHadronicTag = cms.EDProducer("FlashggVHHadronicTagProducer",
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.untracked.double(-0.6),
    PhoMVAThreshold = cms.untracked.double(-0.2),
    SystLabel = cms.string(''),
    cosThetaStarThreshold = cms.untracked.double(0.5),
    dRJetToPhoLThreshold = cms.untracked.double(0.5),
    dRJetToPhoSThreshold = cms.untracked.double(0.5),
    dijetMassHighThreshold = cms.untracked.double(120.0),
    dijetMassLowThreshold = cms.untracked.double(60.0),
    inputTagJets = cms.VInputTag(cms.InputTag("flashggUnpackedJets","0"), cms.InputTag("flashggUnpackedJets","1"), cms.InputTag("flashggUnpackedJets","2"), cms.InputTag("flashggUnpackedJets","3"), cms.InputTag("flashggUnpackedJets","4"), 
        cms.InputTag("flashggUnpackedJets","5"), cms.InputTag("flashggUnpackedJets","6"), cms.InputTag("flashggUnpackedJets","7")),
    jetEtaThreshold = cms.untracked.double(2.4),
    jetPtThreshold = cms.untracked.double(40.0),
    jetsNumberThreshold = cms.untracked.double(2.0),
    leadPhoOverMassThreshold = cms.untracked.double(0.375),
    subleadPhoOverMassThreshold = cms.untracked.double(0.25)
)


process.flashggVHLooseTag = cms.EDProducer("FlashggVHLooseTagProducer",
    DeltaRTrkElec = cms.untracked.double(1.0),
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    ElectronPtThreshold = cms.untracked.double(20.0),
    ElectronTag = cms.InputTag("flashggSelectedElectrons"),
    EtaCuts = cms.untracked.vdouble(1.442, 1.566, 2.5),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    HighEtaPhoThreshold = cms.untracked.double(2.5),
    LongitudinalImpactParam = cms.untracked.double(0.02),
    LowPtEtaPhoThreshold = cms.untracked.double(1.4447),
    METTag = cms.InputTag("slimmedMETs"),
    METThreshold = cms.untracked.double(45.0),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.untracked.double(-0.6),
    MidPtEtaPhoThreshold = cms.untracked.double(1.566),
    MuonTag = cms.InputTag("flashggSelectedMuons"),
    PhoMVAThreshold = cms.untracked.double(-0.2),
    PuIDCutoffThreshold = cms.untracked.double(0.8),
    SystLabel = cms.string(''),
    TransverseImpactParam = cms.untracked.double(0.2),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    Zmass_ = cms.untracked.double(91.9),
    deltaMassElectronZThreshold_ = cms.untracked.double(10.0),
    deltaRLepPhoThreshold = cms.untracked.double(1),
    deltaRPhoElectronThreshold = cms.untracked.double(1.0),
    electronIsoThreshold = cms.untracked.double(0.15),
    electronNumOfHitsThreshold = cms.untracked.double(1),
    inputTagJets = cms.VInputTag(cms.InputTag("flashggUnpackedJets","0"), cms.InputTag("flashggUnpackedJets","1"), cms.InputTag("flashggUnpackedJets","2"), cms.InputTag("flashggUnpackedJets","3"), cms.InputTag("flashggUnpackedJets","4"), 
        cms.InputTag("flashggUnpackedJets","5"), cms.InputTag("flashggUnpackedJets","6"), cms.InputTag("flashggUnpackedJets","7")),
    jetEtaThreshold = cms.untracked.double(2.4),
    jetPtThreshold = cms.untracked.double(20.0),
    jetsNumberThreshold = cms.untracked.double(3.0),
    leadPhoOverMassThreshold = cms.untracked.double(0.375),
    leptonEtaThreshold = cms.untracked.double(2.4),
    leptonPtThreshold = cms.untracked.double(20),
    muPFIsoSumRelThreshold = cms.untracked.double(0.2),
    nonTrigMVAThreshold = cms.untracked.double(0.9),
    subleadPhoOverMassThreshold = cms.untracked.double(0.25)
)


process.flashggVHTightTag = cms.EDProducer("FlashggVHTightTagProducer",
    DeltaRTrkElec = cms.untracked.double(1.0),
    DiPhotonTag = cms.InputTag("flashggDiPhotons"),
    ElectronPtThreshold = cms.untracked.double(20.0),
    ElectronTag = cms.InputTag("flashggSelectedElectrons"),
    EtaCuts = cms.untracked.vdouble(1.442, 1.566, 2.5),
    GenParticleTag = cms.InputTag("flashggPrunedGenParticles"),
    HighEtaPhoThreshold = cms.untracked.double(2.5),
    LongitudinalImpactParam = cms.untracked.double(0.02),
    LowPtEtaPhoThreshold = cms.untracked.double(1.4447),
    METTag = cms.InputTag("slimmedMETs"),
    METThreshold = cms.untracked.double(45.0),
    MVAResultTag = cms.InputTag("flashggDiPhotonMVA"),
    MVAThreshold = cms.untracked.double(-0.6),
    MidPtEtaPhoThreshold = cms.untracked.double(1.566),
    MuonTag = cms.InputTag("flashggSelectedMuons"),
    PhoMVAThreshold = cms.untracked.double(-0.2),
    PuIDCutoffThreshold = cms.untracked.double(0.8),
    SystLabel = cms.string(''),
    TransverseImpactParam = cms.untracked.double(0.2),
    VertexTag = cms.InputTag("offlineSlimmedPrimaryVertices"),
    Zmass_ = cms.untracked.double(91.9),
    deltaMassElectronZThreshold_ = cms.untracked.double(10.0),
    deltaRJetMuonThreshold = cms.untracked.double(0.5),
    deltaRLepPhoThreshold = cms.untracked.double(1),
    deltaRLowPtMuonPhoThreshold = cms.untracked.double(0.5),
    deltaRPhoElectronThreshold = cms.untracked.double(1.0),
    deltaRPhoLeadJet = cms.untracked.double(0.5),
    deltaRPhoSubLeadJet = cms.untracked.double(0.5),
    electronIsoThreshold = cms.untracked.double(0.15),
    electronNumOfHitsThreshold = cms.untracked.double(1),
    inputTagJets = cms.VInputTag(cms.InputTag("flashggUnpackedJets","0"), cms.InputTag("flashggUnpackedJets","1"), cms.InputTag("flashggUnpackedJets","2"), cms.InputTag("flashggUnpackedJets","3"), cms.InputTag("flashggUnpackedJets","4"), 
        cms.InputTag("flashggUnpackedJets","5"), cms.InputTag("flashggUnpackedJets","6"), cms.InputTag("flashggUnpackedJets","7")),
    invMassLepHighThreshold = cms.untracked.double(110.0),
    invMassLepLowThreshold = cms.untracked.double(70.0),
    jetEtaThreshold = cms.untracked.double(2.4),
    jetPtThreshold = cms.untracked.double(20.0),
    jetsNumberThreshold = cms.untracked.double(3.0),
    leadPhoOverMassThreshold = cms.untracked.double(0.375),
    leptonEtaThreshold = cms.untracked.double(2.4),
    leptonLowPtThreshold = cms.untracked.double(10.0),
    leptonPtThreshold = cms.untracked.double(20),
    muPFIsoSumRelThreshold = cms.untracked.double(0.2),
    nonTrigMVAThreshold = cms.untracked.double(0.9),
    numberOfHighPtMuonsThreshold = cms.untracked.double(1.0),
    numberOfLowPtMuonsThreshold = cms.untracked.double(2.0),
    subleadPhoOverMassThreshold = cms.untracked.double(0.25)
)


process.flashggTagTester = cms.EDAnalyzer("FlashggTagTestAnalyzer",
    TagSorter = cms.InputTag("flashggTagSorter")
)


process.vbfTagDumper = cms.EDAnalyzer("CutBasedVBFTagDumper",
    categories = cms.VPSet(cms.PSet(
        histograms = cms.VPSet(),
        label = cms.string('VBFDiJet'),
        subcats = cms.int32(0),
        variables = cms.VPSet(cms.PSet(
            expr = cms.string('diPhoton.sumPt'),
            name = cms.untracked.string('dipho_sumpt')
        ), 
            cms.PSet(
                expr = cms.string('abs(cos(diPhoton.leadingPhoton.phi - diPhoton.subLeadingPhoton.phi))'),
                name = cms.untracked.string('dipho_cosphi')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.mass'),
                name = cms.untracked.string('mass')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.leadingPhoton.pt'),
                name = cms.untracked.string('leadPt')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.leadingPhoton.et'),
                name = cms.untracked.string('leadEt')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.leadingPhoton.eta'),
                name = cms.untracked.string('leadEta')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.leadingPhoton.phi'),
                name = cms.untracked.string('leadPhi')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.leadingPhoton.sigmaIetaIeta'),
                name = cms.untracked.string('lead_sieie')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.leadingPhoton.hadronicOverEm'),
                name = cms.untracked.string('lead_hoe')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.leadingPhoton.sigEOverE'),
                name = cms.untracked.string('lead_sigmaEoE')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.leadingPhoton.pt/diPhoton.mass'),
                name = cms.untracked.string('lead_ptoM')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.leadingPhoton.r9'),
                name = cms.untracked.string('leadR9')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.subLeadingPhoton.pt'),
                name = cms.untracked.string('subleadPt')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.subLeadingPhoton.et'),
                name = cms.untracked.string('subleadEt')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.subLeadingPhoton.eta'),
                name = cms.untracked.string('subleadEta')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.subLeadingPhoton.phi'),
                name = cms.untracked.string('subleadPhi')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.subLeadingPhoton.sigmaIetaIeta'),
                name = cms.untracked.string('sublead_sieie')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.subLeadingPhoton.hadronicOverEm'),
                name = cms.untracked.string('sublead_hoe')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.subLeadingPhoton.sigEOverE'),
                name = cms.untracked.string('sublead_sigmaEoE')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.subLeadingPhoton.pt/diPhoton.mass'),
                name = cms.untracked.string('sublead_ptoM')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.subLeadingPhoton.r9'),
                name = cms.untracked.string('subleadR9')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.leadingView.phoIdMvaWrtChosenVtx'),
                name = cms.untracked.string('leadIDMVA')
            ), 
            cms.PSet(
                expr = cms.string('diPhoton.subLeadingView.phoIdMvaWrtChosenVtx'),
                name = cms.untracked.string('subleadIDMVA')
            ), 
            cms.PSet(
                expr = cms.string('VBFMVA.dijet_abs_dEta'),
                name = cms.untracked.string('dijet_abs_dEta')
            ), 
            cms.PSet(
                expr = cms.string('VBFMVA.dijet_leadEta'),
                name = cms.untracked.string('dijet_leadEta')
            ), 
            cms.PSet(
                expr = cms.string('VBFMVA.dijet_subleadEta'),
                name = cms.untracked.string('dijet_subleadEta')
            ), 
            cms.PSet(
                expr = cms.string('VBFMVA.dijet_leady'),
                name = cms.untracked.string('dijet_leady')
            ), 
            cms.PSet(
                expr = cms.string('VBFMVA.dijet_subleady'),
                name = cms.untracked.string('dijet_subleady')
            ), 
            cms.PSet(
                expr = cms.string('VBFMVA.dijet_LeadJPt'),
                name = cms.untracked.string('dijet_LeadJPt')
            ), 
            cms.PSet(
                expr = cms.string('VBFMVA.dijet_SubJPt'),
                name = cms.untracked.string('dijet_SubJPt')
            ), 
            cms.PSet(
                expr = cms.string('VBFMVA.dijet_Zep'),
                name = cms.untracked.string('dijet_Zep')
            ), 
            cms.PSet(
                expr = cms.string('VBFMVA.dijet_Mjj'),
                name = cms.untracked.string('dijet_Mjj')
            ), 
            cms.PSet(
                expr = cms.string('VBFMVA.dipho_PToM'),
                name = cms.untracked.string('dipho_PToM')
            ), 
            cms.PSet(
                expr = cms.string('VBFMVA.leadPho_PToM'),
                name = cms.untracked.string('leadPho_PToM')
            ), 
            cms.PSet(
                expr = cms.string('VBFMVA.sublPho_PToM'),
                name = cms.untracked.string('sublPho_PToM')
            ), 
            cms.PSet(
                expr = cms.string('VBFMVA.dijet_dphi_trunc'),
                name = cms.untracked.string('dijet_dphi_trunc')
            ), 
            cms.PSet(
                expr = cms.string('VBFMVA.dijet_dipho_pt'),
                name = cms.untracked.string('dijet_dipho_pt')
            ), 
            cms.PSet(
                expr = cms.string('abs(deltaPhi(VBFMVA.leadJet.phi, VBFMVA.subleadJet.phi))'),
                name = cms.untracked.string('dijet_dphi')
            ), 
            cms.PSet(
                expr = cms.string('VBFMVA.dijet_dipho_dphi'),
                name = cms.untracked.string('dijet_dipho_dphi')
            ), 
            cms.PSet(
                expr = cms.string('VBFMVA.dijet_minDRJetPho'),
                name = cms.untracked.string('dijet_minDRJetPho')
            ), 
            cms.PSet(
                expr = cms.string('hasValidVBFTriJet'),
                name = cms.untracked.string('has3Jet')
            ), 
            cms.PSet(
                expr = cms.string('VBFMVA.VBFMVAValue'),
                name = cms.untracked.string('dijet_MVA')
            ), 
            cms.PSet(
                expr = cms.string('VBFMVA.dijet_dipho_dphi'),
                name = cms.untracked.string('dijet_dipho_dphi_trunc')
            ), 
            cms.PSet(
                expr = cms.string('leadingJet.pt'),
                name = cms.untracked.string('jet1_pt')
            ), 
            cms.PSet(
                expr = cms.string('subLeadingJet.pt'),
                name = cms.untracked.string('jet2_pt')
            ), 
            cms.PSet(
                expr = cms.string('subSubLeadingJet.pt'),
                name = cms.untracked.string('jet3_pt')
            ), 
            cms.PSet(
                expr = cms.string('leadingJet.eta'),
                name = cms.untracked.string('jet1_eta')
            ), 
            cms.PSet(
                expr = cms.string('subLeadingJet.eta'),
                name = cms.untracked.string('jet2_eta')
            ), 
            cms.PSet(
                expr = cms.string('subSubLeadingJet.eta'),
                name = cms.untracked.string('jet3_eta')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().pt_J1()'),
                name = cms.untracked.string('jet1_pt_test')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().mjj_J1J2_FggJet()'),
                name = cms.untracked.string('J1J2_mjj')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().mjj_J1J3_FggJet()'),
                name = cms.untracked.string('J1J3_mjj')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().mjj_J2J3_FggJet()'),
                name = cms.untracked.string('J2J3_mjj')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().mjjj_FggJet()'),
                name = cms.untracked.string('Mjjj')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dEta_J1J2_FggJet()'),
                name = cms.untracked.string('J1J2_dEta')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dEta_J1J3_FggJet()'),
                name = cms.untracked.string('J1J3_dEta')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dEta_J2J3_FggJet()'),
                name = cms.untracked.string('J2J3_dEta')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().zepjj_J1J2_FggJet()'),
                name = cms.untracked.string('J1J2_Zep')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().zepjj_J1J3_FggJet()'),
                name = cms.untracked.string('J1J3_Zep')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().zepjj_J2J3_FggJet()'),
                name = cms.untracked.string('J2J3_Zep')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().zepjjj_FggJet()'),
                name = cms.untracked.string('J1J2J3_Zep')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dPhijj_J1J2_FggJet()'),
                name = cms.untracked.string('J1J2_dipho_dPhi')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dPhijj_J1J3_FggJet()'),
                name = cms.untracked.string('J1J3_dipho_dPhi')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dPhijj_J2J3_FggJet()'),
                name = cms.untracked.string('J2J3_dipho_dPhi')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dPhijjj_FggJet()'),
                name = cms.untracked.string('J1J2J3_dipho_dPhi')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dEta_J1J2J3_FggJet()'),
                name = cms.untracked.string('dEta_J1_J2J3')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dEta_J2J3J1_FggJet()'),
                name = cms.untracked.string('dEta_J2_J3J1')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dEta_J3J1J2_FggJet()'),
                name = cms.untracked.string('dEta_J3_J1J2')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dEta_dJ1_J2J3_FggJet()'),
                name = cms.untracked.string('dEta_dJ1_J2J3')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dEta_dJ2_J3J1_FggJet()'),
                name = cms.untracked.string('dEta_dJ2_J3J1')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dEta_dJ3_J1J2_FggJet()'),
                name = cms.untracked.string('dEta_dJ3_J1J2')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().mjj_d12_13plus23_FggJet()'),
                name = cms.untracked.string('dMjj_d12_13plus23')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().mjj_d12_13_FggJet()'),
                name = cms.untracked.string('dMjj_d12_13')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().mjj_d12_23_FggJet()'),
                name = cms.untracked.string('dMjj_d12_23')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().mjj_d13_23_FggJet()'),
                name = cms.untracked.string('dMjj_d13_23')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dR_DP_12_FggJet()'),
                name = cms.untracked.string('dR_dipho_dijet12')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dR_DP_13_FggJet()'),
                name = cms.untracked.string('dR_dipho_dijet13')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dR_DP_23_FggJet()'),
                name = cms.untracked.string('dR_dipho_dijet23')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dR_Ph1_1_FggJet()'),
                name = cms.untracked.string('dR_Photon1_J1')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dR_Ph1_2_FggJet()'),
                name = cms.untracked.string('dR_Photon1_J2')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dR_Ph1_3_FggJet()'),
                name = cms.untracked.string('dR_Photon1_J3')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dR_Ph2_1_FggJet()'),
                name = cms.untracked.string('dR_Photon2_J1')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dR_Ph2_2_FggJet()'),
                name = cms.untracked.string('dR_Photon2_J2')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dR_Ph2_3_FggJet()'),
                name = cms.untracked.string('dR_Photon2_J3')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dR_DP_123_FggJet()'),
                name = cms.untracked.string('dR_dipho_trijet')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().missingP4_dPhi_jjj_FggJet()'),
                name = cms.untracked.string('misPt_dPhi_3J')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().missingP4_dPhi_jj_FggJet()'),
                name = cms.untracked.string('misPt_dPhi_2J')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().missingP4_Pt_jjj_FggJet()'),
                name = cms.untracked.string('misPt_mag_3J')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().missingP4_Pt_jj_FggJet()'),
                name = cms.untracked.string('misPt_mag_2J')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().missingP4_dPhi_d3J2J_FggJet()'),
                name = cms.untracked.string('misPt_dPhi_d3J2J')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().missingP4_Pt_d3J2J_FggJet()'),
                name = cms.untracked.string('misPt_mag_d3J2J')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dPhi_12_FggJet()'),
                name = cms.untracked.string('dPhi_J1_J2')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dPhi_13_FggJet()'),
                name = cms.untracked.string('dPhi_J1_J3')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dPhi_23_FggJet()'),
                name = cms.untracked.string('dPhi_J2_J3')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dPhi_max_FggJet()'),
                name = cms.untracked.string('dPhi_max_jets')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dPhi_min_FggJet()'),
                name = cms.untracked.string('dPhi_min_jets')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().simplex_volume_DP_12_FggJet()'),
                name = cms.untracked.string('momentum4Volume')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dR_min_J13J23_FggJet()'),
                name = cms.untracked.string('dR_min_J12J23')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dR_partonMatchingToJ1()'),
                name = cms.untracked.string('dRToNearestPartonJ1')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dR_partonMatchingToJ2()'),
                name = cms.untracked.string('dRToNearestPartonJ2')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().dR_partonMatchingToJ3()'),
                name = cms.untracked.string('dRToNearestPartonJ3')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().numberOfMatchesAfterDRCut(0.5)'),
                name = cms.untracked.string('numberOfMatches')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().genPV().z'),
                name = cms.untracked.string('genZ')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().pt_genJetMatchingToJ1'),
                name = cms.untracked.string('pt_genJetMatchingToJ1')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().pt_genJetMatchingToJ2'),
                name = cms.untracked.string('pt_genJetMatchingToJ2')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().pt_genJetMatchingToJ3'),
                name = cms.untracked.string('pt_genJetMatchingToJ3')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().eta_genJetMatchingToJ1'),
                name = cms.untracked.string('eta_genJetMatchingToJ1')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().eta_genJetMatchingToJ2'),
                name = cms.untracked.string('eta_genJetMatchingToJ2')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().eta_genJetMatchingToJ3'),
                name = cms.untracked.string('eta_genJetMatchingToJ3')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().hasClosestGenJetToLeadingJet'),
                name = cms.untracked.string('hasClosestGenJetToLeadingJet')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().hasClosestGenJetToSubLeadingJet'),
                name = cms.untracked.string('hasClosestGenJetToSubLeadingJet')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().hasClosestParticleToLeadingJet'),
                name = cms.untracked.string('hasClosestParticleToLeadingJet')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().hasClosestParticleToSubLeadingJet'),
                name = cms.untracked.string('hasClosestParticleToSubLeadingJet')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().hasClosestParticleToLeadingPhoton'),
                name = cms.untracked.string('hasClosestParticleToLeadingPhoton')
            ), 
            cms.PSet(
                expr = cms.string('tagTruth().hasClosestParticleToSubLeadingPhoton'),
                name = cms.untracked.string('hasClosestParticleToSubLeadingPhoton')
            ), 
            cms.PSet(
                expr = cms.string('sqrt((leadingJet.energy+subLeadingJet.energy)^2-(leadingJet.px+subLeadingJet.px)^2-(leadingJet.py+subLeadingJet.py)^2-(leadingJet.pz+subLeadingJet.pz)^2)'),
                name = cms.untracked.string('Mjj')
            ))
    ), 
        cms.PSet(
            histograms = cms.VPSet(),
            label = cms.string('excluded'),
            subcats = cms.int32(0),
            variables = cms.VPSet(cms.PSet(
                expr = cms.string('diPhoton.sumPt'),
                name = cms.untracked.string('dipho_sumpt')
            ), 
                cms.PSet(
                    expr = cms.string('abs(cos(diPhoton.leadingPhoton.phi - diPhoton.subLeadingPhoton.phi))'),
                    name = cms.untracked.string('dipho_cosphi')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton.mass'),
                    name = cms.untracked.string('mass')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton.leadingPhoton.pt'),
                    name = cms.untracked.string('leadPt')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton.leadingPhoton.et'),
                    name = cms.untracked.string('leadEt')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton.leadingPhoton.eta'),
                    name = cms.untracked.string('leadEta')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton.leadingPhoton.phi'),
                    name = cms.untracked.string('leadPhi')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton.leadingPhoton.sigmaIetaIeta'),
                    name = cms.untracked.string('lead_sieie')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton.leadingPhoton.hadronicOverEm'),
                    name = cms.untracked.string('lead_hoe')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton.leadingPhoton.sigEOverE'),
                    name = cms.untracked.string('lead_sigmaEoE')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton.leadingPhoton.pt/diPhoton.mass'),
                    name = cms.untracked.string('lead_ptoM')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton.leadingPhoton.r9'),
                    name = cms.untracked.string('leadR9')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton.subLeadingPhoton.pt'),
                    name = cms.untracked.string('subleadPt')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton.subLeadingPhoton.et'),
                    name = cms.untracked.string('subleadEt')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton.subLeadingPhoton.eta'),
                    name = cms.untracked.string('subleadEta')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton.subLeadingPhoton.phi'),
                    name = cms.untracked.string('subleadPhi')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton.subLeadingPhoton.sigmaIetaIeta'),
                    name = cms.untracked.string('sublead_sieie')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton.subLeadingPhoton.hadronicOverEm'),
                    name = cms.untracked.string('sublead_hoe')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton.subLeadingPhoton.sigEOverE'),
                    name = cms.untracked.string('sublead_sigmaEoE')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton.subLeadingPhoton.pt/diPhoton.mass'),
                    name = cms.untracked.string('sublead_ptoM')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton.subLeadingPhoton.r9'),
                    name = cms.untracked.string('subleadR9')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton.leadingView.phoIdMvaWrtChosenVtx'),
                    name = cms.untracked.string('leadIDMVA')
                ), 
                cms.PSet(
                    expr = cms.string('diPhoton.subLeadingView.phoIdMvaWrtChosenVtx'),
                    name = cms.untracked.string('subleadIDMVA')
                ), 
                cms.PSet(
                    expr = cms.string('VBFMVA.dijet_abs_dEta'),
                    name = cms.untracked.string('dijet_abs_dEta')
                ), 
                cms.PSet(
                    expr = cms.string('VBFMVA.dijet_leadEta'),
                    name = cms.untracked.string('dijet_leadEta')
                ), 
                cms.PSet(
                    expr = cms.string('VBFMVA.dijet_subleadEta'),
                    name = cms.untracked.string('dijet_subleadEta')
                ), 
                cms.PSet(
                    expr = cms.string('VBFMVA.dijet_leady'),
                    name = cms.untracked.string('dijet_leady')
                ), 
                cms.PSet(
                    expr = cms.string('VBFMVA.dijet_subleady'),
                    name = cms.untracked.string('dijet_subleady')
                ), 
                cms.PSet(
                    expr = cms.string('VBFMVA.dijet_LeadJPt'),
                    name = cms.untracked.string('dijet_LeadJPt')
                ), 
                cms.PSet(
                    expr = cms.string('VBFMVA.dijet_SubJPt'),
                    name = cms.untracked.string('dijet_SubJPt')
                ), 
                cms.PSet(
                    expr = cms.string('VBFMVA.dijet_Zep'),
                    name = cms.untracked.string('dijet_Zep')
                ), 
                cms.PSet(
                    expr = cms.string('VBFMVA.dijet_Mjj'),
                    name = cms.untracked.string('dijet_Mjj')
                ), 
                cms.PSet(
                    expr = cms.string('VBFMVA.dipho_PToM'),
                    name = cms.untracked.string('dipho_PToM')
                ), 
                cms.PSet(
                    expr = cms.string('VBFMVA.leadPho_PToM'),
                    name = cms.untracked.string('leadPho_PToM')
                ), 
                cms.PSet(
                    expr = cms.string('VBFMVA.sublPho_PToM'),
                    name = cms.untracked.string('sublPho_PToM')
                ), 
                cms.PSet(
                    expr = cms.string('VBFMVA.dijet_dphi_trunc'),
                    name = cms.untracked.string('dijet_dphi_trunc')
                ), 
                cms.PSet(
                    expr = cms.string('VBFMVA.dijet_dipho_pt'),
                    name = cms.untracked.string('dijet_dipho_pt')
                ), 
                cms.PSet(
                    expr = cms.string('abs(deltaPhi(VBFMVA.leadJet.phi, VBFMVA.subleadJet.phi))'),
                    name = cms.untracked.string('dijet_dphi')
                ), 
                cms.PSet(
                    expr = cms.string('VBFMVA.dijet_dipho_dphi'),
                    name = cms.untracked.string('dijet_dipho_dphi')
                ), 
                cms.PSet(
                    expr = cms.string('VBFMVA.dijet_minDRJetPho'),
                    name = cms.untracked.string('dijet_minDRJetPho')
                ), 
                cms.PSet(
                    expr = cms.string('hasValidVBFTriJet'),
                    name = cms.untracked.string('has3Jet')
                ), 
                cms.PSet(
                    expr = cms.string('VBFMVA.VBFMVAValue'),
                    name = cms.untracked.string('dijet_MVA')
                ), 
                cms.PSet(
                    expr = cms.string('VBFMVA.dijet_dipho_dphi'),
                    name = cms.untracked.string('dijet_dipho_dphi_trunc')
                ), 
                cms.PSet(
                    expr = cms.string('leadingJet.pt'),
                    name = cms.untracked.string('jet1_pt')
                ), 
                cms.PSet(
                    expr = cms.string('subLeadingJet.pt'),
                    name = cms.untracked.string('jet2_pt')
                ), 
                cms.PSet(
                    expr = cms.string('subSubLeadingJet.pt'),
                    name = cms.untracked.string('jet3_pt')
                ), 
                cms.PSet(
                    expr = cms.string('leadingJet.eta'),
                    name = cms.untracked.string('jet1_eta')
                ), 
                cms.PSet(
                    expr = cms.string('subLeadingJet.eta'),
                    name = cms.untracked.string('jet2_eta')
                ), 
                cms.PSet(
                    expr = cms.string('subSubLeadingJet.eta'),
                    name = cms.untracked.string('jet3_eta')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().pt_J1()'),
                    name = cms.untracked.string('jet1_pt_test')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().mjj_J1J2_FggJet()'),
                    name = cms.untracked.string('J1J2_mjj')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().mjj_J1J3_FggJet()'),
                    name = cms.untracked.string('J1J3_mjj')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().mjj_J2J3_FggJet()'),
                    name = cms.untracked.string('J2J3_mjj')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().mjjj_FggJet()'),
                    name = cms.untracked.string('Mjjj')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dEta_J1J2_FggJet()'),
                    name = cms.untracked.string('J1J2_dEta')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dEta_J1J3_FggJet()'),
                    name = cms.untracked.string('J1J3_dEta')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dEta_J2J3_FggJet()'),
                    name = cms.untracked.string('J2J3_dEta')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().zepjj_J1J2_FggJet()'),
                    name = cms.untracked.string('J1J2_Zep')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().zepjj_J1J3_FggJet()'),
                    name = cms.untracked.string('J1J3_Zep')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().zepjj_J2J3_FggJet()'),
                    name = cms.untracked.string('J2J3_Zep')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().zepjjj_FggJet()'),
                    name = cms.untracked.string('J1J2J3_Zep')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dPhijj_J1J2_FggJet()'),
                    name = cms.untracked.string('J1J2_dipho_dPhi')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dPhijj_J1J3_FggJet()'),
                    name = cms.untracked.string('J1J3_dipho_dPhi')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dPhijj_J2J3_FggJet()'),
                    name = cms.untracked.string('J2J3_dipho_dPhi')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dPhijjj_FggJet()'),
                    name = cms.untracked.string('J1J2J3_dipho_dPhi')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dEta_J1J2J3_FggJet()'),
                    name = cms.untracked.string('dEta_J1_J2J3')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dEta_J2J3J1_FggJet()'),
                    name = cms.untracked.string('dEta_J2_J3J1')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dEta_J3J1J2_FggJet()'),
                    name = cms.untracked.string('dEta_J3_J1J2')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dEta_dJ1_J2J3_FggJet()'),
                    name = cms.untracked.string('dEta_dJ1_J2J3')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dEta_dJ2_J3J1_FggJet()'),
                    name = cms.untracked.string('dEta_dJ2_J3J1')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dEta_dJ3_J1J2_FggJet()'),
                    name = cms.untracked.string('dEta_dJ3_J1J2')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().mjj_d12_13plus23_FggJet()'),
                    name = cms.untracked.string('dMjj_d12_13plus23')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().mjj_d12_13_FggJet()'),
                    name = cms.untracked.string('dMjj_d12_13')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().mjj_d12_23_FggJet()'),
                    name = cms.untracked.string('dMjj_d12_23')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().mjj_d13_23_FggJet()'),
                    name = cms.untracked.string('dMjj_d13_23')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dR_DP_12_FggJet()'),
                    name = cms.untracked.string('dR_dipho_dijet12')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dR_DP_13_FggJet()'),
                    name = cms.untracked.string('dR_dipho_dijet13')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dR_DP_23_FggJet()'),
                    name = cms.untracked.string('dR_dipho_dijet23')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dR_Ph1_1_FggJet()'),
                    name = cms.untracked.string('dR_Photon1_J1')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dR_Ph1_2_FggJet()'),
                    name = cms.untracked.string('dR_Photon1_J2')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dR_Ph1_3_FggJet()'),
                    name = cms.untracked.string('dR_Photon1_J3')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dR_Ph2_1_FggJet()'),
                    name = cms.untracked.string('dR_Photon2_J1')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dR_Ph2_2_FggJet()'),
                    name = cms.untracked.string('dR_Photon2_J2')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dR_Ph2_3_FggJet()'),
                    name = cms.untracked.string('dR_Photon2_J3')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dR_DP_123_FggJet()'),
                    name = cms.untracked.string('dR_dipho_trijet')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().missingP4_dPhi_jjj_FggJet()'),
                    name = cms.untracked.string('misPt_dPhi_3J')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().missingP4_dPhi_jj_FggJet()'),
                    name = cms.untracked.string('misPt_dPhi_2J')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().missingP4_Pt_jjj_FggJet()'),
                    name = cms.untracked.string('misPt_mag_3J')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().missingP4_Pt_jj_FggJet()'),
                    name = cms.untracked.string('misPt_mag_2J')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().missingP4_dPhi_d3J2J_FggJet()'),
                    name = cms.untracked.string('misPt_dPhi_d3J2J')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().missingP4_Pt_d3J2J_FggJet()'),
                    name = cms.untracked.string('misPt_mag_d3J2J')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dPhi_12_FggJet()'),
                    name = cms.untracked.string('dPhi_J1_J2')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dPhi_13_FggJet()'),
                    name = cms.untracked.string('dPhi_J1_J3')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dPhi_23_FggJet()'),
                    name = cms.untracked.string('dPhi_J2_J3')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dPhi_max_FggJet()'),
                    name = cms.untracked.string('dPhi_max_jets')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dPhi_min_FggJet()'),
                    name = cms.untracked.string('dPhi_min_jets')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().simplex_volume_DP_12_FggJet()'),
                    name = cms.untracked.string('momentum4Volume')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dR_min_J13J23_FggJet()'),
                    name = cms.untracked.string('dR_min_J12J23')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dR_partonMatchingToJ1()'),
                    name = cms.untracked.string('dRToNearestPartonJ1')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dR_partonMatchingToJ2()'),
                    name = cms.untracked.string('dRToNearestPartonJ2')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().dR_partonMatchingToJ3()'),
                    name = cms.untracked.string('dRToNearestPartonJ3')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().numberOfMatchesAfterDRCut(0.5)'),
                    name = cms.untracked.string('numberOfMatches')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().genPV().z'),
                    name = cms.untracked.string('genZ')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().pt_genJetMatchingToJ1'),
                    name = cms.untracked.string('pt_genJetMatchingToJ1')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().pt_genJetMatchingToJ2'),
                    name = cms.untracked.string('pt_genJetMatchingToJ2')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().pt_genJetMatchingToJ3'),
                    name = cms.untracked.string('pt_genJetMatchingToJ3')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().eta_genJetMatchingToJ1'),
                    name = cms.untracked.string('eta_genJetMatchingToJ1')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().eta_genJetMatchingToJ2'),
                    name = cms.untracked.string('eta_genJetMatchingToJ2')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().eta_genJetMatchingToJ3'),
                    name = cms.untracked.string('eta_genJetMatchingToJ3')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().hasClosestGenJetToLeadingJet'),
                    name = cms.untracked.string('hasClosestGenJetToLeadingJet')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().hasClosestGenJetToSubLeadingJet'),
                    name = cms.untracked.string('hasClosestGenJetToSubLeadingJet')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().hasClosestParticleToLeadingJet'),
                    name = cms.untracked.string('hasClosestParticleToLeadingJet')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().hasClosestParticleToSubLeadingJet'),
                    name = cms.untracked.string('hasClosestParticleToSubLeadingJet')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().hasClosestParticleToLeadingPhoton'),
                    name = cms.untracked.string('hasClosestParticleToLeadingPhoton')
                ), 
                cms.PSet(
                    expr = cms.string('tagTruth().hasClosestParticleToSubLeadingPhoton'),
                    name = cms.untracked.string('hasClosestParticleToSubLeadingPhoton')
                ), 
                cms.PSet(
                    expr = cms.string('sqrt((leadingJet.energy+subLeadingJet.energy)^2-(leadingJet.px+subLeadingJet.px)^2-(leadingJet.py+subLeadingJet.py)^2-(leadingJet.pz+subLeadingJet.pz)^2)'),
                    name = cms.untracked.string('Mjj')
                ))
        )),
    className = cms.untracked.string('CutBasedVBFTagDumper'),
    classifierCfg = cms.PSet(
        categories = cms.VPSet(cms.PSet(
            cut = cms.string('leadingJet.pt>=0'),
            name = cms.untracked.string('VBFDiJet')
        ), 
            cms.PSet(
                cut = cms.string('1'),
                name = cms.untracked.string('excluded')
            ))
    ),
    dumpGlobalVariables = cms.untracked.bool(True),
    dumpHistos = cms.untracked.bool(True),
    dumpTrees = cms.untracked.bool(True),
    dumpWorkspace = cms.untracked.bool(False),
    generatorInfo = cms.InputTag("generator"),
    globalVariables = cms.PSet(
        rho = cms.InputTag("fixedGridRhoAll"),
        vertexes = cms.InputTag("offlineSlimmedPrimaryVertices")
    ),
    intLumi = cms.untracked.double(10000.0),
    lumiWeight = cms.double(53.4782127072),
    maxCandPerEvent = cms.int32(1),
    nameTemplate = cms.untracked.string('$PROCESS_$SQRTS_$CLASSNAME_$SUBCAT_$LABEL'),
    processId = cms.string('qcd'),
    quietRooFit = cms.untracked.bool(False),
    src = cms.InputTag("flashggVBFTag"),
    workspaceName = cms.untracked.string('cms_hgg_$SQRTS')
)


process.flashggTagSequence = cms.Sequence(process.flashggDiPhotonMVA+process.flashggDiPhotonMVANew+process.flashggUnpackedJets+process.flashggVBFMVA+process.flashggVBFMVALegacy+process.flashggVBFDiPhoDiJetMVA+process.flashggVBFDiPhoDiJetMVALegacy+process.flashggUntagged+process.flashggVBFTag+process.flashggTTHLeptonicTag+process.flashggVHEtTag+process.flashggTTHHadronicTag+process.flashggVHLooseTag+process.flashggVHTightTag+process.flashggVHHadronicTag+process.flashggTagSorter)


process.MessageLogger = cms.Service("MessageLogger",
    FrameworkJobReport = cms.untracked.PSet(
        FwkJob = cms.untracked.PSet(
            limit = cms.untracked.int32(10000000),
            optionalPSet = cms.untracked.bool(True)
        ),
        default = cms.untracked.PSet(
            limit = cms.untracked.int32(0)
        ),
        optionalPSet = cms.untracked.bool(True)
    ),
    categories = cms.untracked.vstring('FwkJob', 
        'FwkReport', 
        'FwkSummary', 
        'Root_NoDictionary'),
    cerr = cms.untracked.PSet(
        FwkJob = cms.untracked.PSet(
            limit = cms.untracked.int32(0),
            optionalPSet = cms.untracked.bool(True)
        ),
        FwkReport = cms.untracked.PSet(
            limit = cms.untracked.int32(10000000),
            optionalPSet = cms.untracked.bool(True),
            reportEvery = cms.untracked.int32(1)
        ),
        FwkSummary = cms.untracked.PSet(
            limit = cms.untracked.int32(10000000),
            optionalPSet = cms.untracked.bool(True),
            reportEvery = cms.untracked.int32(1)
        ),
        INFO = cms.untracked.PSet(
            limit = cms.untracked.int32(0)
        ),
        Root_NoDictionary = cms.untracked.PSet(
            limit = cms.untracked.int32(0),
            optionalPSet = cms.untracked.bool(True)
        ),
        default = cms.untracked.PSet(
            limit = cms.untracked.int32(10000000)
        ),
        noTimeStamps = cms.untracked.bool(False),
        optionalPSet = cms.untracked.bool(True),
        threshold = cms.untracked.string('INFO')
    ),
    cerr_stats = cms.untracked.PSet(
        optionalPSet = cms.untracked.bool(True),
        output = cms.untracked.string('cerr'),
        threshold = cms.untracked.string('WARNING')
    ),
    cout = cms.untracked.PSet(
        placeholder = cms.untracked.bool(True)
    ),
    debugModules = cms.untracked.vstring(),
    debugs = cms.untracked.PSet(
        placeholder = cms.untracked.bool(True)
    ),
    default = cms.untracked.PSet(

    ),
    destinations = cms.untracked.vstring('warnings', 
        'errors', 
        'infos', 
        'debugs', 
        'cout', 
        'cerr'),
    errors = cms.untracked.PSet(
        placeholder = cms.untracked.bool(True)
    ),
    fwkJobReports = cms.untracked.vstring('FrameworkJobReport'),
    infos = cms.untracked.PSet(
        Root_NoDictionary = cms.untracked.PSet(
            limit = cms.untracked.int32(0),
            optionalPSet = cms.untracked.bool(True)
        ),
        optionalPSet = cms.untracked.bool(True),
        placeholder = cms.untracked.bool(True)
    ),
    statistics = cms.untracked.vstring('cerr_stats'),
    suppressDebug = cms.untracked.vstring(),
    suppressInfo = cms.untracked.vstring(),
    suppressWarning = cms.untracked.vstring(),
    warnings = cms.untracked.PSet(
        placeholder = cms.untracked.bool(True)
    )
)


process.TFileService = cms.Service("TFileService",
    closeFileFast = cms.untracked.bool(True),
    fileName = cms.string('/afs/cern.ch/work/j/jwright/private/VBFMVAStudy/CMSSW_7_4_15/src/flashgg/Taggers/test/MVATraining/test_diphodijet_training/output_QCD_Pt-30to40_DoubleEMEnriched_MGG-80toInf_TuneCUETP8M1_13TeV_Pythia8.root')
)


process.maxEvents = cms.untracked.PSet(
    input = cms.untracked.int32(4543901)
)

